@include('layouts.dashboard.header')

<main class="content">
    <section class="main-content">
        <div class="title-head">
            <h1>All Submit Quiz</h1>
            
        </div>
        <div class="white-box px-0">
            <div class="table-responsive">
                <table id="datatableid">
                    <thead>
                        <tr>
                            <th class="text-nowrap">First Name</th>
                            <th class="text-nowrap">Last Name</th>
                            <th class="text-nowrap">Email</th>
                            <th class="text-nowrap">Ontraport ID</th>
                            <th class="text-nowrap">Date</th>
                            
                            
                            <th class="text-nowrap">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($all_submit_quiz as $get_users_value)
                        <?php
                        $quiz_json = DB::table('formdata')->where('id',$get_users_value->id)->first();                        
                        $quiz_decode = json_decode($quiz_json->data);

                        // echo "<pre>";
                        // print_r($quiz_decode);exit;

                        // echo "<pre>";
                        // print_r($quiz_decode->question20->firstname);exit;
                        ?>
                        
                        <tr>
                            <td>{{$quiz_decode->question20->firstname}}</td>
                            <td>{{$quiz_decode->question21->lastname}}</td>
                            <td>{{$quiz_decode->question22->email}}</td>
                            <td>{{$get_users_value->ontraport_id}}</td>
                            <td>{{date("d-M-Y", strtotime($get_users_value->created_at))}}</td>
                            
                            
                            <td>
                                <a href="javascript:void(0)" class="btn btn-primary">View</a>
                                <a href="javascript:void(0)" class="btn btn-primary br">Block</a>
                            </td>
                        </tr>

                        @endforeach
                        
                        
                        
                        
                        
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</main>

@include('layouts.dashboard.footer')