@include('layouts.dashboard.header')
 <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"> -->
<style>
    .site-header .for-quiz,
    .floating-setting {
        display: block;
    }

    .alert-success {
      animation: cssAnimation 0s 3s forwards;
      visibility: visible;
    }

    @keyframes cssAnimation {
      to   {visibility: hidden;}
    }
</style>

<main class="content">
    
    <section class="main-content">
        <div class="alert alert-success showbiasmsg" style="text-align: center; display:none;">
            Data updated successfully
        </div>
       
        <div class="title-head">
            <h1>Permanent Break Through</h1>
        </div>
        <div class="white-box">


            <nav>
              <div class="nav nav-tabs" id="nav-tab" role="tablist">
                <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="nav-home" aria-selected="true">BREAK THROUGH</button>
                <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#menu1" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Testimonials</button>
                <button class="nav-link" id="nav-you_get" data-bs-toggle="tab" data-bs-target="#you_get" type="button" role="tab" aria-controls="nav-contact" aria-selected="false">YOU’LL GET</button>
              </div>
            </nav>


           
           


            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="nav-home-tab">
                    <form id="sec_1_submit_3" class="form mt-5" enctype="multipart/form-data">
                        @csrf
                        <div class="title-head">
                            <h3>PERMANENT RELATIONSHIP BREAK THROUGH</h3>
                        </div>
                        <div class="control-group">
                            <label>Title</label>
                            <input type="text" name="sec_1_title" id="sec_1_title" value="{{$get_sellpage3->sec_1_title}}" placeholder="Enter section title">
                        </div>
                        <div class="control-group">
                            <label>Sub-Title</label>
                            <input type="text" name="sec_1_sub_title" id="sec_1_sub_title" value="{{$get_sellpage3->sec_1_sub_title}}" placeholder="Enter section sub-title">
                        </div>

                        <div class="control-group">
                            <label>Image</label><br>
                            <img height="auto" width="60px" src="">
                            <input class="mt-2" type="file" id="sec_1_image" name="sec_1_image">
                        </div>
                        <div class="control-group">
                            <label>Description</label>
                            <input type="text" name="sec_1_des" id="sec_1_des" value="{{$get_sellpage3->sec_1_des}}" placeholder="Enter section sub-title">
                        </div>
                        <div class="control-group">
                            <label>Description Bellow</label>
                            <input type="text" name="sec_1_des_bellow" id="sec_1_des_bellow" value="{{$get_sellpage3->sec_1_des_bellow}}" placeholder="Enter section sub-title">
                        </div>
                        <div class="control-group">
                            <label>Link</label>
                            <input type="text" name="sec_1_link" id="sec_1_link" placeholder="Enter section sub-title" value="{{$get_sellpage3->sec_1_link}}">
                        </div>
                        <div class="control-group">
                            <label>Bellow Link</label>
                            <input type="text" name="sec_1_link_bellow" id="sec_1_link_bellow" placeholder="Enter section sub-title" value="{{$get_sellpage3->sec_1_link_bellow}}">
                        </div>

                        <div class="form-btn">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
                <div class="tab-pane fade" id="menu1" role="tabpanel" aria-labelledby="nav-profile-tab">
                    <!-- <a href="{{url('admin/1-on-1-testimonial/add')}}" class="btn btn-primary" style="float:right; margin-right: 10px">Add New</a> -->
                    <div class="table-responsive mt-5 mb-3">
                        <a href="javascript:void(0)" onclick="showtes_form()" class="btn btn-primary" style="float:right; margin-right: 10px">Add New</a>
                    </div>
                    <div class="table-responsive" id="test_list">
                        <table>
                            <thead>
                                <tr>
                                    <th class="text-nowrap">Title</th>
                                    <th class="text-nowrap">Name</th>                                    
                                    <th class="text-nowrap">Image</th>
                                    <th class="text-nowrap">Status</th>
                                    <th class="text-nowrap">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($get_testimonials as $get_testimonials_value)
                                <tr>
                                    <td>{{$get_testimonials_value->testimonial_name_3}}</td>
                                    <td>{{$get_testimonials_value->testimonial_title_3}}</td>
                                    
                                    <td><img width="25px" height="auto" src="{{asset('images/backend/pages_3/'.$get_testimonials_value->testimonial_image_3)}}" alt=""></td>
                                    @if($get_testimonials_value->testimonial_status_3 == 0)
                                    <td><span style="color:green">Active</span></td>
                                    @else
                                    <td><span style="color:red">Inactive</span></td>
                                    @endif
                                    <td>
                                        <a href="" class="btn btn-primary">Edit</a>
                                        <a href="" class="btn btn-primary">Delete</a>
                                    </td>
                                </tr>
                                @endforeach                        
                            </tbody>
                        </table>
                    </div>
                    <div class="table-responsive" id="test_form" style="display:none">
                        <form id="break_thr_form" class="form" enctype="multipart/form-data">
                            @csrf
                    
                            <div class="control-group">
                                <label>Title</label>
                                <input type="text" name="testimonial_title" placeholder="Enter section title" value="">
                            </div>
                            <div class="control-group">
                                <label>Sub-Title</label>
                                <input type="text" name="testimonial_subtitle" id="sec_1_sub_title" placeholder="Enter section sub-title" value="">
                            </div>
                            <div class="control-group">
                                <label>Description</label>
                                <textarea type="text" name="testimonial_description" placeholder="Write your description"></textarea>
                            </div>
                            <div class="control-group">
                                <label>Name</label>
                                <input type="text" name="testimonial_name" placeholder="Enter name" value="">
                            </div>
                            <div class="control-group">
                                <label>Designation</label>
                                <input type="text" name="testimonial_designation" placeholder="Enter designation" value="">
                            </div>
                            <div class="control-group">
                                <label>Image</label>
                                <input type="file" name="testimonial_image" id="testimonial_image_3">
                            </div>
                            <div class="form-btn">
                                <button type="submit" class="btn btn-primary">Add</button>
                            </div>
                        </form>
                    </div>
                 
                </div>

                <div class="tab-pane fade show" id="you_get" role="tabpanel" aria-labelledby="nav-you_get">
                    <div class="table-responsive mt-5 mb-3">
                        <a href="javascript:void(0)" onclick="show_add_element()" class="btn btn-primary" style="float:right; margin-right: 10px">Add Elements</a>
                    </div>

                    <div class="table-responsive" id="main_you_get">
                        @foreach($get_sec3_element as $get_sec3_element_value)
                        <div class="col-md-2">
                            <img src="{{asset('images/backend/pages_3/'.$get_sec3_element_value->sec_3_element_img)}}"><br><label class="mt-2" style="text-align:center;">{{$get_sec3_element_value->sec_3_element_title}}</label>
                        </div>
                        @endforeach
                        <form id="sec_3_submit_3" class="form mt-5" enctype="multipart/form-data">
                            @csrf
                            
                            <div class="control-group">
                                <label>Title</label>
                                <input type="text" name="sec_3_element_title" id="sec_3_element_title" value="" placeholder="Enter section title">
                            </div>
                            <div class="control-group">
                                <label>Sub-Title</label>
                                <input type="text" name="sec_3_title" id="sec_3_title" value="" placeholder="Enter section sub-title">
                            </div>
                            <div class="form-btn">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </form>
                    </div>

                    <div class="table-responsive" id="element_you_get" style="display:none">
                        <form id="sec_3_submit_3_element" class="form" enctype="multipart/form-data">
                            @csrf
                    
                            <div class="control-group">
                                <label>Title</label>
                                <input type="text" name="sec_3_element_title" placeholder="Enter section title" value="">
                            </div>
                            
                            <div class="control-group">
                                <label>Image</label>
                                <input type="file" name="sec_3_element_img" id="sec_3_element_img">
                            </div>
                            <div class="form-btn">
                                <button type="submit" class="btn btn-primary">Add</button>
                            </div>
                        </form>
                    </div>


                </div>
                <!-- <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">...</div> -->
            </div>

<!-- Tabs content -->
           
        </div>
<!-- Tabs content -->
        </div>
    </section>
    <!-- <aside class="ques-aside">
        <div class="single">
        </div>
        <div class="single">
            <div class="d-flex align-items justify-content-between equal_gutter">
                <label class="mb-0">Add background image</label>
                <button href="javascript:void(0)" class="btn btn-grey sm upload-btn">
                    Add <input type="file" id="background_image_upload" accept=".png, .jpg, .jpeg">
                </button>
                <div id="background_image_preview" class="upload-preview" style="display: none;">
                    <figure></figure>
                </div>
            </div>
        </div>
        <div class="single">
           
        </div>
    </aside> -->
</main>


@include('layouts.dashboard.footer')
<script src="//cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<script type="text/javascript">
    $("#sec_1_submit_3").submit(function(e){
        e.preventDefault();

        var sec_1_image = $('#sec_1_image').prop('files')[0]; 
        var formData = new FormData(this);

        $.ajax({
            enctype: 'multipart/form-data',
            url: "/sec-1-submit-3",
            type: "POST",
            dataType: "json",
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            success: function(data){
                if(data.status==1){
                   $('.showbiasmsg').css('display',''); 
                   $("#tttttttt").load(" #tttttttt");
                }
            },
        });
    });
</script>


<!-- For tab 2nd -->

<script>
    function showtes_form(){
        $('#test_form').css('display','');
        $('#test_list').css('display','none');
    }

    $('document').ready(function(){
        $('#nav-profile-tab').click(function(){
            $('#test_form').css('display','none')
            $('#test_list').css('display','');
        })
        $("#break_thr_form").submit(function(e){
        e.preventDefault();

        var testimonial_image = $('#testimonial_image_3').prop('files')[0]; 
        var formData = new FormData(this);

            $.ajax({
                enctype: 'multipart/form-data',
                url: "/page3-testimonial",
                type: "POST",
                dataType: "json",
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: function(data){
                    if(data.status==1){
                       alert('Done')
                    }
                },
            });
        });
    })
</script>



<!-- You get -->


<script>
    function show_add_element(){
        $('#element_you_get').css('display','');
        $('#main_you_get').css('display','none');
    }


    $('document').ready(function(){
        $('#nav-profile-tab').click(function(){
            $('#test_form').css('display','none')
            $('#test_list').css('display','');
        })

        // $('#nav-you_get').click(function(){
        //     $('#element_you_get').css('display','none')
        //     $('#sec_3_submit_3').css('display','');
        // })

        

        $("#break_thr_form").submit(function(e){
        e.preventDefault();

        var testimonial_image = $('#testimonial_image_3').prop('files')[0]; 
        var formData = new FormData(this);

            $.ajax({
                enctype: 'multipart/form-data',
                url: "/page3-testimonial",
                type: "POST",
                dataType: "json",
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: function(data){
                    if(data.status==1){
                       alert('Done')
                    }
                },
            });
        });
    })
</script>

<script type="text/javascript">
    $("#sec_3_submit_3").submit(function(e){
        e.preventDefault();

        var formData = new FormData(this);

        $.ajax({
            enctype: 'multipart/form-data',
            url: "/sec-3-submit-3",
            type: "POST",
            dataType: "json",
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            success: function(data){
                if(data.status==1){
                   $('.showbiasmsg').css('display',''); 
                   $("#tttttttt").load(" #tttttttt");
                }
            },
        });
    });
</script>

<script type="text/javascript">
    $("#sec_3_submit_3_element").submit(function(e){
        e.preventDefault();

        var sec_3_element_img = $('#sec_3_element_img').prop('files')[0]; 
        var formData = new FormData(this);

        $.ajax({
            enctype: 'multipart/form-data',
            url: "/sec-3-element-submit-3",
            type: "POST",
            dataType: "json",
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            success: function(data){
                if(data.status==1){
                   $('.showbiasmsg').css('display',''); 
                   $("#tttttttt").load(" #tttttttt");
                }
            },
        });
    });
</script>



