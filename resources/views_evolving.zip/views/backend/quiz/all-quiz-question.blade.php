<?php 
$all_question = DB:: table('quiz_question')->get();
?>
<style>
    ques-aside .ques-list>li .num-box:after {
    counter-increment: none!important;
    content: transparent!important;
</style>
<ul id="sortable_questions" class="ques-list equal_y_gutter">
    @foreach($all_question as $all_question_value)
    <li class="ui-state-default">
        <div class="num-box">
            <figure class="icon">
                <img src="images/welcome-icon.png" alt="">
            </figure>
        </div>
        <span>{{$all_question_value->question}}</span>
        <div class="dropdown">
            <button class="dropdown-toggle" type="button" id="quiz_action_button" data-bs-toggle="dropdown" aria-expanded="false"><i class="las la-ellipsis-v"></i></button>
            <ul class="dropdown-menu" aria-labelledby="quiz_action_button">
                <li>
                    <a href="javascript:void(0)">Delete</a>
                </li>
                <li>
                    <a href="javascript:void(0)">Duplicate</a>
                </li>
                <li>
                    <a href="{{url('admin/score-quiz/'.$all_question_value->id)}}">Edit</a>
                </li>
                <!-- <li>
                    <a href="{{url('admin/edit-question/'.$all_question_value->id)}}">Edit</a>
                </li> -->
            </ul>
        </div>
    </li>

    @endforeach
    
</ul> 