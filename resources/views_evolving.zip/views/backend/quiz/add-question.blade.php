@include('layouts.dashboard.header')

<style>
    .site-header .for-quiz,
    .floating-setting {
        display: block;
    }

    .alert-success {
      animation: cssAnimation 0s 3s forwards;
      visibility: visible;
    }

    @keyframes cssAnimation {
      to   { visibility: hidden;}
    }
</style>


<main class="content">
    @if(session()->has('add'))
    <div class="alert alert-success" style="text-align: center;">
        {{ session()->get('add') }}
    </div>
    @endif
    <section class="main-content">
        <div class="alert alert-success showbiasmsg" style="text-align: center; display:none">
            Data updated successfully
        </div>
        <div class="title-head">
            <h1>Add Question</h1>
        </div>
        <div class="white-box">
            <form id="submit_add_que" class="form">
                @csrf
                <input id="quetype" type="hidden" name="question_type" value="multiple_choice_click">
                <div class="control-group">
                    <label>Question Field Type</label>
                    <div class="dropdown look-like-select">
                        <button class="dropdown-toggle text-start" type="button" id="question_type_button" data-bs-toggle="dropdown" aria-expanded="false">
                            <span class="icon"><img src="images/tick-icon.png" alt=""></span> Multiple Choice
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="question_type_button">
                            <li>
                                <a href="javascript:void(0)" id="multiple_choice_click" class="active clicllink">
                                    <span class="icon">
                                        <img src="images/tick-icon.png" alt="">
                                    </span> Multiple Choice
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0)" id="short_text_click" class="clicllink">
                                    <span class="icon">
                                        <img src="images/short-text-icon.png" alt="">
                                    </span> Short Text
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0)" id="long_text_click" class="clicllink">
                                    <span class="icon">
                                        <img src="images/long-text-icon.png" alt="">
                                    </span> Long Text
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0)" id="yes_no_click"  class="clicllink">
                                    <span class="icon">
                                        <img src="images/yes-no-icon.png" alt="">
                                    </span> Yes/No
                                </a>
                            </li>
                            <li>
                               <a href="javascript:void(0)" id="ranking_click"  class="clicllink">
                                    <span class="icon">
                                        <img src="images/ranking-icon.png" alt="">
                                    </span> Ranking
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0)" id="email_click"  class="clicllink">
                                    <span class="icon">
                                        <i class="fas fa-envelope"></i>
                                    </span> Email
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0)" id="phone_click" class="clicllink">
                                    <span class="icon">
                                        <img src="images/phone-icon.png" alt="">
                                    </span> Phone Number
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0)" id="number_click" class="clicllink">
                                    <span class="icon">
                                        <i class="fas fa-list-ol"></i>
                                    </span> Number
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0)" id="rating_click" class="clicllink">
                                    <span class="icon">
                                        <img src="images/rating-icon.png" alt="">
                                    </span> Rating
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0)" id="date_click" class="clicllink">
                                    <span class="icon">
                                        <img src="images/date-icon.png" alt="">
                                    </span> Date
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0)" id="end_screen_click" class="clicllink">
                                    <span class="icon">
                                        <img src="images/end-screen-icon.png" alt="">
                                    </span> End Screen
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="control-group">
                    <label>Question</label>
                    <textarea type="text" name="question" placeholder="Write your question"></textarea>
                </div>
                <div class="control-group">
                    <label>Description</label>
                    <textarea type="text" name="description" placeholder="Write your question"></textarea>
                </div>
                <div class="control-group">
                    <label>Question Number</label>
                    <input type="text" name="question_no">
                </div>

                <div class="control-group">
                    <label>Question Type</label>
                    <select name="type_question">
                        <option value="1">Primary Gift</option>
                        <option value="2">Primary Shadow</option>
                    </select>
                </div>

                <div class="control-group" id="do_variation">
                    <label>Do You Need Variation</label>
                    <input  type="checkbox" class="switch-input" name="variation" id="clickcheckbox" value="">
                </div>

                
                <!-- <div class="control-group">
                    <label>Setting</label>
                    <div class="ques-setting">
                        <div class="switch-input-list">
                            <label>
                                <span>Required</span>
                                <input class="switch-input" type="checkbox">
                            </label>
                            <label>
                                <span>Multiple selection</span>
                                <input class="switch-input" type="checkbox">
                            </label>
                            <label>
                                <span>Randomize</span>
                                <input class="switch-input" type="checkbox">
                            </label>
                            <label>
                                <span>"Other" option</span>
                                <input class="switch-input" type="checkbox">
                            </label>
                        </div>
                    </div>
                </div> -->
                <div class="control-group" id="chanhetext">
                    <label>Options - <span style="color:#8A2F35">Variation 1</span></label>
                    <ul id="sortable_options" class="options-list">
                        <li class="ui-state-default">
                            <input type="text" placeholder="Write your option">
                        </li>
                    </ul>
                    <a id="add_more_option" href="javascript:void(0)" class="add-btn">Add choice</a>
                </div>

                <div id="showupformulti">

                    <div class="control-group" id="add_more_choice" style="display: none;">
                        <label>Options - <span style="color:#8A2F35">Variation 1</span></label>
                        <ul id="sortable_options" class="options-list">
                            <li class="ui-state-default">
                                <input type="text" name="question_option[]" placeholder="Write your option">
                            </li>

                                <input type="hidden" name="value[]" value="Passion">                            
                                <input type="hidden" name="value_2[]" value="Addiction">
                                <input type="hidden" name="value_3[]" value="Internal">
                                <input type="hidden" name="value_4[]" value="Implicit">
                                <input type="hidden" name="value_5[]" value="Directive">
                                <input type="hidden" name="value_6[]" value="Autonomous">
                                <input type="hidden" name="value_7[]" value="Initiation">

                            <li class="ui-state-default">
                                <input type="text" name="question_option[]" placeholder="Write your option">
                            </li>

                                <input type="hidden" name="value[]" value="Devotion">                            
                                <input type="hidden" name="value_2[]" value="Anxious">
                                <input type="hidden" name="value_3[]" value="External">
                                <input type="hidden" name="value_4[]" value="No Option">
                                <input type="hidden" name="value_5[]" value="Collaborative">
                                <input type="hidden" name="value_6[]" value="Engaged">
                                <input type="hidden" name="value_7[]" value="No option">


                            <li class="ui-state-default">
                                <input type="text" name="question_option[]" placeholder="Write your option">
                            </li>

                                <input type="hidden" name="value[]" value="Truth">                            
                                <input type="hidden" name="value_2[]" value="Control">
                                <input type="hidden" name="value_3[]" value="Internal">
                                <input type="hidden" name="value_4[]" value="Explicit">
                                <input type="hidden" name="value_5[]" value="Directive">
                                <input type="hidden" name="value_6[]" value="Autonomous">
                                <input type="hidden" name="value_7[]" value="Initiation">


                            <li class="ui-state-default">
                                <input type="text" name="question_option[]" placeholder="Write your option">
                            </li>

                                <input type="hidden" name="value[]" value="Harmony">                            
                                <input type="hidden" name="value_2[]" value="Collapse">
                                <input type="hidden" name="value_3[]" value="External">
                                <input type="hidden" name="value_4[]" value="Implicit">
                                <input type="hidden" name="value_5[]" value="Collaborative">
                                <input type="hidden" name="value_6[]" value="Engaged">
                                <input type="hidden" name="value_7[]" value="Reciprocating">


                            <li class="ui-state-default">
                                <input type="text" name="question_option[]" placeholder="Write your option">
                            </li>

                                <input type="hidden" name="value[]" value="Possibility">                            
                                <input type="hidden" name="value_2[]" value="Complaint">
                                <input type="hidden" name="value_3[]" value="No Option">
                                <input type="hidden" name="value_4[]" value="Explicit">
                                <input type="hidden" name="value_5[]" value="No Option">
                                <input type="hidden" name="value_6[]" value="No Option">
                                <input type="hidden" name="value_7[]" value="Initiation">


                            <li class="ui-state-default">
                                <input type="text" name="question_option[]" placeholder="Write your option">
                            </li>

                                <input type="hidden" name="value[]" value="Freedom">                            
                                <input type="hidden" name="value_2[]" value="Avoidance">
                                <input type="hidden" name="value_3[]" value="Internal">
                                <input type="hidden" name="value_4[]" value="No Option">
                                <input type="hidden" name="value_5[]" value="Directive">
                                <input type="hidden" name="value_6[]" value="Autonomous">
                                <input type="hidden" name="value_7[]" value="No option">


                            <li class="ui-state-default">
                                <input type="text" name="question_option[]" placeholder="Write your option">
                            </li>

                                <input type="hidden" name="value[]" value="Partnership">                            
                                <input type="hidden" name="value_2[]" value="Addiction">
                                <input type="hidden" name="value_3[]" value="External">
                                <input type="hidden" name="value_4[]" value="Explicit">
                                <input type="hidden" name="value_5[]" value="Collaborative">
                                <input type="hidden" name="value_6[]" value="Engaged">
                                <input type="hidden" name="value_7[]" value="Reciprocating">


                            <li class="ui-state-default">
                                <input type="text" name="question_option[]" placeholder="Write your option">
                            </li>

                                <input type="hidden" name="value[]" value="Appreciation">                            
                                <input type="hidden" name="value_2[]" value="Defense">
                                <input type="hidden" name="value_3[]" value="No Option">
                                <input type="hidden" name="value_4[]" value="Implicit">
                                <input type="hidden" name="value_5[]" value="No Option">
                                <input type="hidden" name="value_6[]" value="No Option">
                                <input type="hidden" name="value_7[]" value="Reciprocating">
                            </li>
                        </ul>
                        
                    </div>




                    <div class="control-group" id="chanhetext2" style="display:none">
                        <label>Options - <span style="color:#8A2F35">Variation 2</span></label>
                        <ul id="sortable_options" class="options-list">
                            <li class="ui-state-default">
                                <input type="text" placeholder="Write your option">
                            </li>
                        </ul>
                        <a id="add_more_option2" href="javascript:void(0)" class="add-btn">Add choice</a>
                    </div>

                    <div class="control-group" id="add_more_choice2" style="display: none;">
                        <label>Options - <span style="color:#8A2F35">Variation 2</span></label>
                        <ul id="sortable_options" class="options-list">
                            <li class="ui-state-default">
                                <input type="text" name="question_option_2[]" placeholder="Write your option">
                            </li>

                                <input type="hidden" name="value_2[]" value="Passion">                            
                                <input type="hidden" name="value_2_2[]" value="Addiction">
                                <input type="hidden" name="value_3_2[]" value="Internal">
                                <input type="hidden" name="value_4_2[]" value="Implicit">
                                <input type="hidden" name="value_5_2[]" value="Directive">
                                <input type="hidden" name="value_6_2[]" value="Autonomous">
                                <input type="hidden" name="value_7_2[]" value="Initiation">

                            <li class="ui-state-default">
                                <input type="text" name="question_option_2[]" placeholder="Write your option">
                            </li>

                                <input type="hidden" name="value_2[]" value="Devotion">                            
                                <input type="hidden" name="value_2_2[]" value="Anxious">
                                <input type="hidden" name="value_3_2[]" value="External">
                                <input type="hidden" name="value_4_2[]" value="No Option">
                                <input type="hidden" name="value_5_2[]" value="Collaborative">
                                <input type="hidden" name="value_6_2[]" value="Engaged">
                                <input type="hidden" name="value_7_2[]" value="No option">


                            <li class="ui-state-default">
                                <input type="text" name="question_option_2[]" placeholder="Write your option">
                            </li>

                                <input type="hidden" name="value_2[]" value="Truth">                            
                                <input type="hidden" name="value_2_2[]" value="Control">
                                <input type="hidden" name="value_3_2[]" value="Internal">
                                <input type="hidden" name="value_4_2[]" value="Explicit">
                                <input type="hidden" name="value_5_2[]" value="Directive">
                                <input type="hidden" name="value_6_2[]" value="Autonomous">
                                <input type="hidden" name="value_7_2[]" value="Initiation">


                            <li class="ui-state-default">
                                <input type="text" name="question_option_2[]" placeholder="Write your option">
                            </li>

                                <input type="hidden" name="value[]_2" value="Harmony">                            
                                <input type="hidden" name="value_2_2[]" value="Collapse">
                                <input type="hidden" name="value_3_2[]" value="External">
                                <input type="hidden" name="value_4_2[]" value="Implicit">
                                <input type="hidden" name="value_5_2[]" value="Collaborative">
                                <input type="hidden" name="value_6_2[]" value="Engaged">
                                <input type="hidden" name="value_7_2[]" value="Reciprocating">


                            <li class="ui-state-default">
                                <input type="text" name="question_option_2[]" placeholder="Write your option">
                            </li>

                                <input type="hidden" name="value_2[]" value="Possibility">                            
                                <input type="hidden" name="value_2_2[]" value="Complaint">
                                <input type="hidden" name="value_3_2[]" value="No Option">
                                <input type="hidden" name="value_4_2[]" value="Explicit">
                                <input type="hidden" name="value_5_2[]" value="No Option">
                                <input type="hidden" name="value_6_2[]" value="No Option">
                                <input type="hidden" name="value_7_2[]" value="Initiation">


                            <li class="ui-state-default">
                                <input type="text" name="question_option_2[]" placeholder="Write your option">
                            </li>

                                <input type="hidden" name="value_2[]" value="Freedom">                            
                                <input type="hidden" name="value_2_2[]" value="Avoidance">
                                <input type="hidden" name="value_3_2[]" value="Internal">
                                <input type="hidden" name="value_4_2[]" value="No Option">
                                <input type="hidden" name="value_5_2[]" value="Directive">
                                <input type="hidden" name="value_6_2[]" value="Autonomous">
                                <input type="hidden" name="value_7_2[]" value="No option">


                            <li class="ui-state-default">
                                <input type="text" name="question_option_2[]" placeholder="Write your option">
                            </li>

                                <input type="hidden" name="value_2[]" value="Partnership">                            
                                <input type="hidden" name="value_2_2[]" value="Addiction">
                                <input type="hidden" name="value_3_2[]" value="External">
                                <input type="hidden" name="value_4_2[]" value="Explicit">
                                <input type="hidden" name="value_5_2[]" value="Collaborative">
                                <input type="hidden" name="value_6_2[]" value="Engaged">
                                <input type="hidden" name="value_7_2[]" value="Reciprocating">


                            <li class="ui-state-default">
                                <input type="text" name="question_option_2[]" placeholder="Write your option">
                            </li>

                                <input type="hidden" name="value_2[]" value="Appreciation">                            
                                <input type="hidden" name="value_2_2[]" value="Defense">
                                <input type="hidden" name="value_3_2[]" value="No Option">
                                <input type="hidden" name="value_4_2[]" value="Implicit">
                                <input type="hidden" name="value_5_2[]" value="No Option">
                                <input type="hidden" name="value_6_2[]" value="No Option">
                                <input type="hidden" name="value_7_2[]" value="Reciprocating">
                            </li>
                        </ul>
                        
                    </div>
                </div>


                <div class="form-btn">
                    <button type="submit" class="btn btn-primary">Add</button>
                </div>
            </form>
        </div>
    </section>
    <aside class="ques-aside">
        <div class="single">
            <div class="d-flex align-items justify-content-between equal_gutter">
                <label class="mb-0">Add background image</label>
                <button href="javascript:void(0)" class="btn btn-grey sm upload-btn">
                    Add <input type="file" id="background_image_upload" accept=".png, .jpg, .jpeg">
                </button>
                <div id="background_image_preview" class="upload-preview" style="display: none;">
                    <figure></figure>
                </div>
            </div>
        </div>
        <div class="single">
            @include('backend.quiz.all-quiz-question')
        </div>
    </aside>
</main>

@include('layouts.dashboard.footer')

<script>
    $(document).on("click", '#add_more_option', function () {
       
        $('#add_more_choice').css('display','');
        $('#chanhetext').css('display','none');
    });

    $(document).on("click", '#add_more_option2', function () {
       
        $('#add_more_choice2').css('display','');
        $('#chanhetext2').css('display','none');
    });
</script>

<script>
     $(document).ready(function(){

        $('.clicllink').click(function(){
            
            var click_value = $(this).attr('id');
            if(click_value == "multiple_choice_click"){
                $('#quetype').val('multiple_choice_click')
                $('#do_variation').show();
                $('#showupformulti').css('display','');
                $("#question_type_button").text("Multiple Choice");
                $("#chanhetext").html('<label>Options</label><ul id="sortable_options" class="options-list"><li class="ui-state-default"><input type="text" name="question_option[]" placeholder="Write your option"></li></ul><a id="add_more_option" href="javascript:void(0)" class="add-btn">Add choice</a>');
            }else if(click_value == "short_text_click"){
                $('#quetype').val('short_text_click')
                $('#do_variation').hide();
                $('#showupformulti').css('display','none');
                $("#question_type_button").text("Short Text");
                $("#chanhetext").html('<label>Answers</label><input type="text" name="description" value="Write your answers">')
            }else if(click_value == "long_text_click"){
                $('#quetype').val('long_text_click')
                $('#do_variation').hide();
                $("#question_type_button").text("Long Text");
                $("#chanhetext").html('<label>Answers</label><input type="text" name="description" value="Write your answers" readonly>')
            }else if(click_value == "yes_no_click"){
                $('#quetype').val('yes_no_click')
                $('#do_variation').hide();
                $("#question_type_button").text("Yes/No");
                $("#chanhetext").html('<label>Yer or No</label><div class="row"><div class="col-md-3"><input class="mb-3" type="text" value="Yes" name="yes" readonly><input type="text" value="No" name="no" readonly></div></div>')
            }else if(click_value == "ranking_click"){
                $('#quetype').val('ranking_click')
                $('#do_variation').hide();
                $("#question_type_button").text("Ranking");
                $("#chanhetext").html('<div class="row flex-md-row-reverse"><div class="col-md-4"><div class="row row-cols-2 row-cols-md-1"><div class="col"><div class="control-group"><label>How many top rankings?</label><select name="top-ranking"> <option value="01">1</option><option value="02">2</option><option value="03">3</option><option value="04">4</option><option value="05">5</option></select></div></div><div class="col"><div class="control-group mb-0"><label>Rank least option?</label><select name="least-ranking"><option value="yes">Yes</option><option value="no">No</option></select></div></div></div></div><div class="col-md-8"><label>Drag and drop to rank options</label><ul id="sortable_options" class="options-list right-space"><li class="ui-state-default"><input type="text" placeholder="Write your option"></li></ul><a id="add_more_option" href="javascript:void(0)" class="add-btn">Add choice</a></div></div>')
            }else if(click_value == "email_click"){
                $('#quetype').val('email_click')
                $('#do_variation').hide();
                $("#question_type_button").text("Email");
                $("#chanhetext").html('<label>Email</label><input type="text" name="email" value="Write your email" readonly>')
            }else if(click_value == "phone_click"){
                $('#quetype').val('phone_click')
                $('#do_variation').hide();
                $("#question_type_button").text("Phone Number");
                $("#chanhetext").html('<label>Setting</label><div class="ques-setting"><div class="switch-input-list"><label><span>Required</span><input class="switch-input" type="checkbox"></label><div class="extra-field look-like-select"><select class="countrypicker" name="country"></select></div></div></div>')
            }else if(click_value == "number_click"){
                $('#quetype').val('number_click')
                $('#do_variation').hide();
                $("#question_type_button").text("Number");
                $("#chanhetext").html('<label>Answers</label><input type="text" name="description" value="Write your answers" readonly>')
            }else if(click_value == "rating_click"){
                $('#quetype').val('rating_click')
                $('#do_variation').hide();
                $("#question_type_button").text("Rating");
                $("#chanhetext").html('<label>Setting</label><div class="ques-setting"><div class="switch-input-list"><label><span>Required</span><input class="switch-input" type="checkbox"></label><div class="rating-options look-like-select"><select name="rating-count" class="small-select"><option value="01">1</option><option value="02">2</option><option value="03">3</option><option value="04">4</option><option value="05" selected>5</option></select><select name="icon" class="select2-icon"><option value="fa-star" data-icon="fa-star" selected>Stars</option><option value="fa-heart" data-icon="fa-heart">Hearts</option><option value="fa-user" data-icon="fa-user">User</option><option value="fa-thumbs-up" data-icon="fa-thumbs-up">Thumbs Up</option><option value="fa-crown" data-icon="fa-crown">Crown</option><option value="fa-cat" data-icon="fa-cat">Cats</option><option value="fa-dog" data-icon="fa-dog">Dogs</option><option value="fa-circle" data-icon="fa-circle">Circles</option><option value="fa-flag" data-icon="fa-flag">Flags</option><option value="fa-tint" data-icon="fa-tint">Droplets</option><option value="fa-check" data-icon="fa-check">Ticks</option><option value="fa-lightbulb" data-icon="fa-lightbulb">Lightbulbs</option><option value="fa-cloud" data-icon="fa-cloud">Clouds</option><option value="fa-bolt" data-icon="fa-bolt">Thunderbolts</option><option value="fa-pencil-alt" data-icon="fa-pencil-alt">Pencils</option><option value="fa-skull" data-icon="fa-skull">Skulls</option></select></div></div></div>')
            }else if(click_value == "date_click"){
                $('#quetype').val('date_click')
                $('#do_variation').hide();
                $("#question_type_button").text("Date");
                $("#chanhetext").html('<label>Setting</label><div class="ques-setting"><div class="switch-input-list"><label><span>Required</span><input class="switch-input" type="checkbox"></label></div><div class="date-options equal_gutter"><label>Date format</label><select name="date-format" class="mb-3"><option value="MMDDYYYY">MMDDYYYY</option><option value="DDMMYYYY">DDMMYYYY</option><option value="YYYYMMDD">YYYYMMDD</option></select><select name="date-separator"><option value="01">/</option><option value="02">-</option><option value="03">.</option></select></div></div>')
            }else if(click_value == "end_screen_click"){
                $('#quetype').val('end_screen_click');
                $('#do_variation').hide();
                $("#question_type_button").text("End Screen");
                $("#chanhetext").html('<label>Email</label><input type="text" name="email" value="Write your email" readonly>');
            }
        });
        
     });


// Add question
$("#submit_add_que").submit(function(e){
     e.preventDefault();
     var formData = $("#submit_add_que").serialize();
         $.ajax({
          url: "/multiple-question",
          type: "POST",
          dataType: "json",
          data: formData,
          success: function(data){
            if(data.status==1){
                $('.showbiasmsg').css('display','');
               // Swal.fire('Data updated succesfully!');
               // $('#submit_add_que')[0].reset();
            }
          }
      });
  })
</script>


<script>
    $(document).ready(function () {

      $('#clickcheckbox').click(function () {

        if ($(this).prop('checked')) {
           $('#clickcheckbox').val(1)
           $('#chanhetext2').css('display','')
        }
        else {
           $('#clickcheckbox').val(0)
           $('#chanhetext2').css('display','none')
           $('#add_more_choice2').css('display','none')
        }
      });

  });
</script>