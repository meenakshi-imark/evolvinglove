<div class="feedback-box pt-3 my-6">
    <h3 class="color_black mb-2">Give Us Some Feedback</h3>
    <p>How well does this section of your Relationship Archetype profile represent you?</p>
    <div class="pt-2 star-rating">
        <input id="star1-5" type="radio" name="rating1" value="star1-5" />
        <label for="star1-5" title="Loved it">
            <i class="las la-star"></i>
        </label>
        <input id="star1-4" type="radio" name="rating1" value="star1-4" />
        <label for="star1-4" title="Liked it">
            <i class="las la-star"></i>
        </label>
        <input id="star1-3" type="radio" name="rating1" value="star1-3" />
        <label for="star1-3" title="It was okay">
            <i class="las la-star"></i>
        </label>
        <input id="star1-2" type="radio" name="rating1" value="star1-2" />
        <label for="star1-2" title="Didn't like it">
            <i class="las la-star"></i>
        </label>
        <input id="star1-1" type="radio" name="rating1" value="star1-1" />
        <label for="star1-1" title="Hated it">
            <i class="las la-star"></i>
        </label>
    </div>

    <figure class="overlay-position">
        <img src="{{ asset('images/feedback/'.$relationship_lookup_text['feedback_icon'])}}" alt="Evolving Love Feedback Background - Male Zen Master">
    </figure>
</div>