<aside class="sidebar free-report">
    <div class="sideMap">
        <h2 class="color_black">Your Relationship Archetype Report</h2>
        <p>Your Evolving Love Archetypes gifts and shadow qualities at a glance</p>

        <ul class="mt-5 mb-6 site-menu">
            <li>
                <a href="/free-report">Result Summary</a>
            </li>
            <li class="locked">
                <a href="/upgrade-profile">Introduction</a>
            </li>
            <li class="locked">
                <a href="/upgrade-profile">Ring Of Resolution</a>
            </li>
            <li class="locked">
                <a href="/upgrade-profile">How To Read Your Results</a>
            </li>
            <li class="sub-dropdown">
                <a href="#primary-gifts">Relationship Archetype</a>
                <ul>
                    <li>
                        <a href="#primary-gifts">Primary Gifts</a>
                    </li>
                    <li>
                        <a href="#relationship-qualities">Relationship Qualities</a>
                    </li>
                    <li class="locked">
                        <a href="/upgrade-profile">Themes</a>
                    </li>
                    <li class="locked">
                        <a href="/upgrade-profile">Relationship Skills</a>
                    </li>
                    <li class="locked">
                        <a href="/upgrade-profile">Reference (Internal vs External)</a>
                    </li>
                    <li class="locked">
                        <a href="/upgrade-profile">Tendencies</a>
                    </li>
                    <li class="locked">
                        <a href="/upgrade-profile">Energetic Profile</a>
                    </li>
                    <li class="locked">
                        <a href="/upgrade-profile">Communication Profile</a>
                    </li>
                    <li class="locked">
                        <a href="/upgrade-profile">Decision-Making Profile</a>
                    </li>
                    <li class="locked">
                        <a href="/upgrade-profile">Parenting Profile</a>
                    </li>
                    <li class="locked">
                        <a href="/upgrade-profile">Erotic Profile</a>
                    </li>
                </ul>
            </li>
            <li class="sub-dropdown">
                <a href="#shadow-qualities">Shadow Archetype</a>
                <ul>
                    <li>
                        <a href="#shadow-qualities">Shadow Qualities</a>
                    </li>
                    <li>
                        <a href="#toxic-cycle">Toxic Cycle</a>
                    </li>
                    <li class="locked">
                        <a href="/upgrade-profile">Sensitivities</a>
                    </li>
                    <li class="locked">
                        <a href="/upgrade-profile">Primary Needs</a>
                    </li>
                    <li class="locked">
                        <a href="/upgrade-profile">Biggest Doubts & Fears</a>
                    </li>
                    <li class="locked">
                        <a href="/upgrade-profile">Most Triggered By</a>
                    </li>
                    <li class="locked">
                        <a href="/upgrade-profile">Conflict Profile</a>
                    </li>
                </ul>
            </li>
            <li class="locked">
                <a href="/upgrade-profile">How To Partner With You</a>
            </li>
            <li class="locked">
                <a href="/upgrade-profile">Permanent Breakthrough</a>
            </li>
        </ul>
    </div>
    <div class="sideBox" style="background-image: url('{{ asset('images/Evolving Love Sidebar & Practices Background - Red.png')}}');">
        <h3>UPGRADE NOW: Full Report + Step by Step Course </h3>
        <p>Get 1:1 private guidance on how to use your Evolving Love archetype’s strengths and permanently resolve your biggest conflicts.</p>
        <a href="/upgrade-profile" class="btn btn-white br w-100">GET MY FULL REPORT</a>
    </div>
</aside>