@extends('layouts.app')	
@section('content')
<header id="header" class="site-header" style="background-image: url('{{ asset('images/Evolving Love Sidebar & Practices Background - Red.png')}}');">
    <nav>
        <div class="left">
            <a href="javascript:void(0)" class="site-hamburgur d-lg-none">
                <i class="las la-bars"></i>
            </a>
            <a href="/" class="site-logo">
                <img src="{{ asset('images/evolving-love-logo.png')}}" alt="">
            </a>
        </div>
        <div class="right">
 
            @php 
            $datasession = session()->all();
            $url = url('/');
            @endphp
            @if(session()->has('formid'))
            @php
            $id = base64_encode("formid".$datasession['formid']);
            $share_url = $url.'/shared-profile?formid='.$id;
            @endphp
            @else
            @php
            $id = "";
            $share_url = "";
            @endphp
            @endif
            <a href="{{$share_url}}"  class="btn btn-white">SHARE YOUR PROFILE <img src="{{ asset('images/Evolving Love Icon - Share (White).png')}}" alt="" ></a>
            @php $route = Route::current()->getName(); @endphp
            @if(Auth::check())
            <div class="dropdown">
                <button class="btn btn-transparent dropdown-toggle" type="button" id="menuDrop" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-cog"></i>
                </button>
                <div class="dropdown-menu" aria-labelledby="menuDrop">
                    <ul>
                        <li><a href="{{ route('my-account') }}">My Account <i class="fas fa-user"></i></a></li>
                        <li><a href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                      
                                    <span>Logout<i class="fas fa-sign-out-alt"></i></span>
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                        @csrf
                                    </form>
                    </li>
                    </ul>
                </div>
            </div>
            @else
            <div class="dropdown">
                <button class="btn btn-transparent dropdown-toggle" type="button" id="menuDrop" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-cog"></i>
                </button>
                <div class="dropdown-menu" aria-labelledby="menuDrop">
                    <ul>
                        <li><a href="/">Login <i class="fas fa-user"></i></a></li>
                    </ul>
                </div>
            </div>
            @endif

        </div>
    </nav>
</header>

<div class="overlay-layer d-lg-none"></div>

@endsection