@extends('layouts.app')	
@section('content')
<header id="header" class="site-header" style="background-image: url('images/Evolving Love Sidebar & Practices Background - Red.png');">
    <nav>
        <a href="javascript:void(0)" class="site-logo">
            <img src="images/evolving-love-logo.png" alt="">
        </a>
        <div class="right">
            <a href="#shopping_cart" class="btn btn-white upgrade-btn">GET MY SESSION</a>
        </div>
    </nav>
</header>
@endsection