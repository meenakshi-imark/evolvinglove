

<div class="floating-setting for-quiz d-lg-none">
    <a id="floating_setting" href="javascript:void(0)" class="btn btn-secondary btn-icon"><i class="las la-sliders-h"></i></a>

    <div class="layout">
        <div class="inner"></div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>


<!-- <script src="js/bootstrap-select-country.min.js"></script> -->
<script src="{{asset('/dashboard/js/bundle.min.js')}}"></script>
<script src="{{asset('/dashboard/js/custom.js')}}"></script>







<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/searchbuilder/1.4.1/js/dataTables.searchBuilder.min.js"></script>
<script src="https://cdn.datatables.net/datetime/1.4.0/js/dataTables.dateTime.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>

<!-- For Developer use -->
<script src="{{asset('/dashboard/js/developer.js')}}"></script>
<script>
    $("#ergvhgvh").submit(function(e) {
        
     e.preventDefault();
     alert("Hi");
     $.ajax({
         
            url:'/welcome-screen-bg',
            data: {welcome_screen_bg : welcome_screen_bg  },
            
            
            sucess: function (d) {
                 alert(d);
            }
        });
  })
</script>

<script>
 $(document).ready(function() {
    $('#datatableid').DataTable( {
        dom: 'Qlfrtip'
    });
});
</script>


</body>

</html>