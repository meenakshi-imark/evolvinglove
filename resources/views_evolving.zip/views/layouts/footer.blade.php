<footer id="footer" class="site-footer background_primary">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12 col-md-7">
                <ul>
                    <li>
                        <a href="/quiz">FREE QUIZ</a>
                    </li>
                    <li>
                        <a href="/about">About</a>
                    </li>
                    <li>
                        <a href="/work-with-us">WORK WITH US</a>
                    </li>
                    <li>
                        <a href="/contact-us">Contact Us</a>
                    </li>
                </ul>
            </div>
            <div class="col-12 col-md-5 text-center text-md-end">
                <p><a href="/questions">QUESTION</a></p>
            </div>
        </div>
    </div>
</footer>
<script type="text/javascript"> (function(d, src, c) { var t=d.scripts[d.scripts.length - 1],s=d.createElement('script');s.id='la_x2s6df8d';s.defer=true;s.src=src;s.onload=s.onreadystatechange=function(){var rs=this.readyState;if(rs&&(rs!='complete')&&(rs!='loaded')){return;}c(this);};t.parentElement.insertBefore(s,t.nextSibling);})(document, 'https://imark.ladesk.com/scripts/track.js', function(e){ LiveAgent.createButton('w4dcq13i', e); }); </script>
<script src="{{ asset('js/app.js') }}"></script>
<script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
<script src="{{ asset('js/bundle.min.js') }}"></script>
<script src="{{ asset('js/custom.js') }}"></script>
<script src="{{ asset('js/developer.js') }}"></script>

</body>

</html>