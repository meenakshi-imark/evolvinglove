<aside class="sidebar">
    <div class="sideMap">
        <h2 class="color_black">Mastering Your Relationship Archetype</h2>
        <p>A Step By Step Guide To Your Profile</p>
        <div class="progress mb-3">
            @php
            $datasession = session()->all();
            $check_steps = DB::table('progress_steps')->where('formid',$datasession['formid'])->first();
            @endphp

            @if($check_steps)
            @php 
            $total = round($check_steps->page1+$check_steps->page2+$check_steps->page3+$check_steps->page4+$check_steps->page5+$check_steps->page6+$check_steps->page7+$check_steps->page8+$check_steps->page9+
            $check_steps->page10+$check_steps->page11+$check_steps->page12+$check_steps->page13+$check_steps->page14+$check_steps->page15+$check_steps->page16+$check_steps->page17+$check_steps->page18+
            $check_steps->page19+$check_steps->page20+$check_steps->page21+$check_steps->page22+$check_steps->page23+$check_steps->page24);
            $finaltotal = $total;
            @endphp
            @else
            @php 
            $finaltotal = 0;
            @endphp
            @endif
            <div class="progress-bar" role="progressbar" style="width: {{$finaltotal}}%" aria-valuenow="17" aria-valuemin="0" aria-valuemax="100"></div>
        </div>

        @php $route = Route::current()->getName(); @endphp
        <p class="text-center">{{$finaltotal}}% Complete</p>
        <ul class="mt-5 mb-6 site-menu">
            <li class="marked-complete">
                <a href="/introduction" class="{{ $route== 'introduction' ? 'active' : '' }}">Introduction</a>
            </li>
            <li class="marked-complete" >
                <a href="/ring-of-resolution" class="{{ $route== 'ring-of-resolution' ? 'active' : '' }}">Ring Of Resolution</a>
            </li>
            <li class="marked-complete">
                <a href="/how-to-read-your-results" class="{{ $route== 'how-to-read-your-results' ? 'active' : '' }}">How To Read Your Results</a>
            </li>
            <li class="marked-complete">
                <a href="/result-summary" class="{{ $route== 'result-summary' ? 'active' : '' }}">Result Summary</a>
            </li>
            <li class="sub-dropdown">
                <a href="javascript:void(0)">Relationship Archetype</a>
                <ul>
                    <li>
                        <a href="/primary-gifts" class="{{ $route== 'primary-gifts' ? 'active' : '' }}">Primary Gifts</a>
                    </li>
                    <li>
                        <a href="/relationship-qualities" class="{{ $route== 'relationship-qualities' ? 'active' : '' }}">Relationship Qualities</a>
                    </li>
                    <li>
                        <a href="/themes" class="{{ $route== 'themes' ? 'active' : '' }}">Themes</a>
                    </li>
                    <li>
                        <a href="/relationship-skills" class="{{ $route== 'relationship-skills' ? 'active' : '' }}">Relationship Skills</a>
                    </li>
                    <li>
                        <a href="/reference" class="{{ $route== 'reference' ? 'active' : '' }}">Reference (Internal vs External)</a>
                    </li>
                    <li>
                        <a href="/tendencies" class="{{ $route== 'tendencies' ? 'active' : '' }}">Tendencies</a>
                    </li>
                    <li>
                        <a href="/energetic-profile"  class="{{ $route== 'energetic-profile' ? 'active' : '' }}">Energetic Profile</a>
                    </li>
                    <li> 
                        <a href="/communication-profile"  class="{{ $route== 'communication-profile' ? 'active' : '' }}">Communication Profile</a>
                    </li>
                    <li>
                        <a href="/decision-making-profile" class="{{ $route== 'decision-making-profile' ? 'active' : '' }}">Decision-Making Profile</a>
                    </li>
                    <li>
                        <a href="/parenting-profile" class="{{ $route== 'parenting-profile' ? 'active' : '' }}">Parenting Profile</a>
                    </li>
                    <li>
                        <a href="/erotic-profile" class="{{ $route== 'erotic-profile' ? 'active' : '' }}">Erotic Profile</a>
                    </li>
                </ul>
            </li>
            <li class="sub-dropdown">
                <a href="javascript:void(0)">Shadow Archetype</a>
                <ul>
                    <li>
                        <a href="/shadow-qualities" class="{{ $route== 'shadow-qualities' ? 'active' : '' }}">Shadow Qualities</a>
                    </li>
                    <li>
                        <a href="/toxic-cycle" class="{{ $route== 'toxic-cycle' ? 'active' : '' }}">Toxic Cycle</a>
                    </li>
                    <li>
                        <a href="/sensitivities" class="{{ $route== 'sensitivities' ? 'active' : '' }}">Sensitivities</a>
                    </li>
                    <li>
                        <a href="/primary-needs" class="{{ $route== 'primary-needs' ? 'active' : '' }}">Primary Needs</a>
                    </li>
                    <li>
                        <a href="biggest-doubts-and-fears" class="{{ $route== 'biggest-doubts-and-fears' ? 'active' : '' }}">Biggest Doubts & Fears</a>
                    </li>
                    <li>
                        <a href="/most-triggered-by" class="{{ $route== 'most-triggered-by' ? 'active' : '' }}">Most Triggered By</a>
                    </li>
                    <li>
                        <a href="/conflict-profile" class="{{ $route== 'conflict-profile' ? 'active' : '' }}">Conflict Profile</a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="/how-to-partner-with-you" class="{{ $route== 'how-to-partner-with-you' ? 'active' : '' }}">How To Partner With You</a>
            </li>
            <li>
                <a href="/permanent-breakthrough" class="{{ $route== 'permanent-breakthrough' ? 'active' : '' }}">Permanent Breakthrough</a>
            </li>
        </ul>
        <a href="javascript:void(0)" class="btn btn-primary br w-100 mb-6">ASK THE COMMUNITY</a>
    </div>
    <div class="sideBox" style="background-image: url('{{ asset('images/Evolving Love Sidebar & Practices Background - Red.png')}}');">
        <h3>Wanna Develop Your Relationship Skills?</h3>
        <p>Get 1:1 private guidance on how to use your Evolving Love archetype’s gifts and permanently resolve your biggest conflicts.</p>
        <a href="javascript:void(0)" class="btn btn-white br w-100">YES, I WANT SKILLS!</a>
    </div>
</aside>