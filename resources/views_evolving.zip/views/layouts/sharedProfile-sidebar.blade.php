<aside class="sidebar free-report shared-profile">
    <div class="sideMap">
        <h2 class="color_black">Your Relationship Archetype Report</h2>
        <p>Your Evolving Love Archetypes gifts and shadow qualities at a glance</p>

        <ul class="mt-5 mb-6 site-menu">
            <li>
                <a href="/free-report">Result Summary</a>
            </li>
            <li class="locked">
                <a href="/quiz">Introduction</a>
            </li>
            <li class="locked">
                <a href="/quiz">Ring Of Resolution</a>
            </li>
            <li class="locked">
                <a href="/quiz">How To Read Your Results</a>
            </li>
            <li class="sub-dropdown">
                <a href="#primary-gifts">Relationship Archetype</a>
                <ul>
                    <li>
                        <a href="#primary-gifts">Primary Gifts</a>
                    </li>
                    <li>
                        <a href="#relationship-qualities">Relationship Qualities</a>
                    </li>
                    <li class="locked">
                        <a href="/quiz">Themes</a>
                    </li>
                    <li class="locked">
                        <a href="/quiz">Relationship Skills</a>
                    </li>
                    <li class="locked">
                        <a href="/quiz">Reference (Internal vs External)</a>
                    </li>
                    <li class="locked">
                        <a href="/quiz">Tendencies</a>
                    </li>
                    <li class="locked">
                        <a href="/quiz">Energetic Profile</a>
                    </li>
                    <li class="locked">
                        <a href="/quiz">Communication Profile</a>
                    </li>
                    <li class="locked">
                        <a href="/quiz">Decision-Making Profile</a>
                    </li>
                    <li class="locked">
                        <a href="/quiz">Parenting Profile</a>
                    </li>
                    <li class="locked">
                        <a href="/quiz">Erotic Profile</a>
                    </li>
                </ul>
            </li>
            <li class="sub-dropdown">
                <a href="#shadow-qualities">Shadow Archetype</a>
                <ul>
                    <li>
                        <a href="#shadow-qualities">Shadow Qualities</a>
                    </li>
                    <li>
                        <a href="#toxic-cycle">Toxic Cycle</a>
                    </li>
                    <li class="locked">
                        <a href="/quiz">Sensitivities</a>
                    </li>
                    <li class="locked">
                        <a href="/quiz">Primary Needs</a>
                    </li>
                    <li class="locked">
                        <a href="/quiz">Biggest Doubts & Fears</a>
                    </li>
                    <li class="locked">
                        <a href="/quiz">Most Triggered By</a>
                    </li>
                    <li class="locked">
                        <a href="/quiz">Conflict Profile</a>
                    </li>
                </ul>
            </li>
            <li class="locked">
                <a href="/quiz">How To Partner With You</a>
            </li>
            <li class="locked">
                <a href="/quiz">Permanent Breakthrough</a>
            </li>
        </ul>
    </div>
    <div class="sideBox" style="background-image: url('{{ asset('images/Evolving Love Sidebar & Practices Background - Red.png')}}');">
        <h3>What To Take The Evolving Love Archetype Quiz?</h3>
        <p>Unlock the key to understand your greatest gifts and your deepest shadows as a romantic partners, family members, or friend. You're about to see yourself and your partner in a whole new light.</p>
        <a href="/quiz" class="btn btn-white br w-100">Take my free quiz now</a>
    </div>
</aside>