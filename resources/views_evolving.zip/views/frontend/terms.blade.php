@include('layouts.front-header')
<style>
    .site-header nav .right,
    .site-header nav .left .site-hamburgur {
        display: none;
    }
</style>

<main class="content">
    <section class="tc-content uSpace">
        <div class="container">
            <h2 class="text-center">Participation Agreement</h2>
            <p>Terms and conditions for participation in the Evolving Love <strong>Mastering Your Relationship Archetype Course</strong>.</p>
            <p>This is an agreement between Quadratic Leadership Inc., d.b.a. Evolving Love (herein referred to as the “Company”) and you (herein referred to as "Client"). Please READ Carefully. By purchasing this product you agree to the follow terms stated herein.</p>

            <h4>PROGRAM / SERVICE</h4>
            <p>Evolving Love (the "Company) agrees to provide the course, "<strong>Mastering Your Relationship Archetype</strong>" (herein referred to as the "Course") identified in our online shopping cart. Client agrees to abide by all policies and procedures as outlined in this agreement as a condition of their participation in the Program.</p>

            <h4>DISCLAIMER:</h4>
            <p>The Client recognizes that Bryan Franklin, Jennifer Russell and the Company do not make any warrants or guarantees about the Client's love life, sex life, relationship status, or mental health either during or after completion of the Course. The Company and it's agents do not accept responsibility for any errors, inaccuracies in, or omissions from, the information and experiences provided during or in relation to the Course.</p>
            <p>Client understands Bryan Franklin, Jennifer Russell and Evolving Love (The Company) are not lawyers, doctors, managers, therapists, or psychotherapists. Client understands that the Company has not promised, shall not be obligated to and will not; (1) introduce Client to the Company's network of contacts (2) procure or attempt to procure a partner or relationship for the Client; (3) act as a therapist providing psychoanalysis, psychological counseling or behavioral therapy; Client understands that a relationship does not exist between the parties after the conclusion of this Course. If the Parties continue their relationship, a separate agreement will be entered into.</p>

            <h4>FEES:</h4>
            <p>The fee for the Evolving Love Mastering Your Relationship Archetype Course:</p>
            <p>FULL PAYMENT: 1 payment of $99 (due today) or a discounted amount after coupon codes are applied.</p>

            <h4>METHODS OF PAYMENT:</h4>
            <p>If Client elects to pay by installments, Client authorizes the Company to charge Client’s credit card or debit card. If Client elects to pay in FULL, Client may pay by credit card or debit card.</p>
            <p>Client with a late or outstanding balance may not be permitted to access content until Client’s payments are current.</p>

            <h4>EVOLVING LOVE COURSE REFUND POLICY</h4>
            <p><strong>Canceling Your Enrollment Within The 3 Day Cooling-off Period</strong>. If you choose to cancel your enrollment for any reason within 3 business days of purchase, then we will refund you the total amount. Please allow up to 10 business days after your refund has been approved for your refund to be processed. Participants must notify us in writing during this period explaining that they are electing to drop the Course and are requesting a refund. Send this correspondence via email to <a href="mailto:info@evolvinglove.us">info@evolvinglove.us</a> on or before the refund period date in order to be eligible for a full refund. After the refund period, the Client acknowledges that all remaining payments are due.</p>
            <p>All refunds are discretionary. To further clarify, we will not provide refunds after the 3 Day Cooling-off period from your date of purchase and all payments must be made on a timely basis. If payments are not made on time, you agree to pay interest on all past-due sums at a rate of 1.5% per month.</p>
            <p>If you have any questions or problems, please let us know by contacting our support team directly. Support can be reached at: info@evolvinglove.us</p>

            <h4>INTELLECTUAL PROPERTY</h4>
            <p>The Evolving Love Course is copyrighted and original materials that have been provided to Client are for Client’s individual use only and a single-user license. Client is not authorized to use any of Company’s intellectual property for Client’s business purposes. Client shall not reproduce any course materials in whole or in part, these materials are for the Client's sole use. All intellectual property, including Company’s copyrighted course and/or course materials, shall remain the sole property of Quadratic Inc. (d.b.a. Evolving Love) No license to sell or distribute Company’s materials is granted or implied. By purchasing this product, Client agrees</p>
            <p>(1) not to infringe any copyright, patent, trademark, trade secret, or other intellectual property rights,</p>
            <p>(2) that any Confidential Information shared by the Company is confidential and proprietary, and belongs solely and exclusively to the Company,</p>
            <p>(3) Client agrees not to disclose such information to any other person or use it in any manner other than in discussion with the Company.</p>
            <p>Further, by purchasing this product, Client agrees that if Client violates, or displays any likelihood of violating, any of Client’s agreements contained in this paragraph, the Company will be entitled to injunctive relief to prohibit any such violations and to protect against the harm of such violations.</p>

            <h4>PHYSICAL & PSYCHOLOGICAL HEALTH</h4>
            <p>Client acknowledges that the Course may be emotionally challenging and stressful. The Client is responsible for their own mental and physical safety and well being. This Course is not intended, nor appropriate for people with diagnosed mental or emotional conditions. If Client has a history of any medical or psychological problems, the Company strongly advises and encourages that Client seek out the help of a professional.</p>

            <h4>CLIENT RESPONSIBILITY</h4>
            <p>The Course is developed for strictly educational purposes ONLY. Client accepts and agrees that Client is 100% responsible for their progress and results from the Course. Company makes no representations, warranties or guarantees verbally or in writing. Client understands that because of the nature of the Course and extent, the results experienced by each Client may significantly vary. Client acknowledges that as with any endeavor, there is no guarantee that Client will reach their goals as a result of participation in the Course. Course education and information is intended for a general audience and does not purport to be, nor should it be construed as, specific advice tailored to any individual. Company assumes no responsibility for errors or omissions that may appear in any program materials.</p>

            <h4>COMMUNITY GUIDELINES</h4>
            <p>Evolving Love's International community, like any community, functions best when its users follow a few simple rules. By accessing and/or using the website, forum, calls, and facebook group you agree to comply with these community guidelines (the “Community Guidelines”) and that:</p>
            <ul>
                <li>You will comply with all applicable laws in your use of the websites and will not use the website for any unlawful purpose;</li>
                <li>
                    You will not upload, post, email, transmit, or otherwise make available any content that:
                    <ul>
                        <li>infringes any copyright, trademark, right of publicity, or other proprietary rights of any person or entity; or</li>
                        <li>is defamatory, libelous, indecent, obscene, pornographic, sexually explicit, invasive of another’s privacy, promotes violence, or contains hate speech (i.e., speech that attacks or demeans a group based on race or ethnic origin, religion, disability, gender, age, veteran status, and/or sexual orientation/gender identity; or</li>
                        <li>discloses any sensitive information about another person, including that person’s email address, postal address, phone number, credit card information, or any similar information.</li>
                    </ul>
                </li>
                <li>You will not “stalk,” threaten, or otherwise harass another person;</li>
                <li>You will not spam or use the website or facebook group to engage in any commercial activities;</li>
                <li>If you post any Registered User Content, you will stay on topic;</li>
                <li>You will not access or use the website to collect any market research for a competing business;</li>
                <li>You will not impersonate any person or entity or falsely state or otherwise misrepresent your affiliation with a person or entity;</li>
                <li>You will not interfere with or attempt to interrupt the proper operation of the website through the use of any virus, device, information collection or transmission mechanism, software or routine, or access or attempt to gain access to any data, files, or passwords related to the website through hacking, password or data mining, or any other means;</li>
                <li>You will not cover, obscure, block, or in any way interfere with any advertisements and/or safety features (e.g., report abuse button) on the website;</li>
                <li>You will not use any robot, spider, scraper, or other automated means to access the website for any purpose without our express written permission; provided, however, we grant the operators of public search engines permission to use spiders to copy materials from the public portions of the website for the sole purpose of and solely to the extent necessary for creating publicly-available searchable indices of the materials, but not caches or archives of such materials;</li>
                <li>You will not take any action that imposes or may impose (in our sole discretion) an unreasonable or disproportionately large load on our technical infrastructure; and</li>
                <li>You will let us know about inappropriate content of which you become aware. If you find something that violates our Community Guidelines, please let us know, and we’ll review it.</li>
            </ul>
            <p>We reserve the right, in our sole and absolute discretion, to deny you access to the website, facebook group, or calls without notice, and to remove any content that does not adhere to these Community Guidelines.</p>

            <h4>LIMITATION OF LIABILITY / HOLD HARMLESS:</h4>
            <p>Client agrees they used Company’s services at their own risk and that the Course is only an educational service being provided. Client releases Bryan Franklin, Jennifer Russell, the Company, its officers, employees, directors, contractors, representatives, subsidiaries, principals, agents, heirs, executors, administrators, successors, assigns, Instructors, guides, staff, Participants, and related entities any way as well as the venue where the Courses are being held (if applicable) and any of its owners, executives, agents, or staff (hereinafter "Releasees") from any and all damages that may result from any claims arising from any agreements, all actions, causes of action, contracts, claims, suits, costs, demands and damages of whatever nature or kind in law or in equity arising from my participation in the Course. Client accepts any and all risks, foreseeable or unforeseeable. Client agrees that Company will not be held liable for any damages of any kind resulting or arising from including but not limited to; direct, indirect, incidental, special, negligent, consequential, or exemplary damages happening from the use or misuse of Company’s services or enrollment in the Course. Company assumes no responsibility for errors or omissions that may appear in any of the program materials. You also understand that any testimonials or endorsements by our customers, clients or audience represented on our courses, websites, content, landing pages, sales pages or offerings have not been scientifically evaluated by us and the results experienced by individuals may vary significantly.</p>

            <h4>FORCE MAJEURE</h4>
            <p>In the event that any cause beyond the reasonable control of either Party, including without limitation acts of God, war, curtailment or interruption of transportation facilities, threats or acts of terrorism, State Department travel advisory, labor strike or civil disturbance, make it inadvisable, illegal, or impossible, either because of unreasonable increased costs or risk of injury, for either Company to perform its obligations under this Agreement, the Company’s performance shall be extended without liability for the period of delay or inability to perform due to such occurrence.</p>

            <h4>SEVERABILITY/WAIVER</h4>
            <p>If any provision of this Agreement is held by to be invalid or unenforceable, the remaining provisions shall nevertheless continue in full force. The failure of either Party to exercise any right provided for herein will not be deemed a waiver of that right or any further rights hereunder.</p>

            <h4>NON-DISPARAGEMENT</h4>
            <p>The Parties agree and accept that the only venue for resolving such a dispute shall be in the venue set forth herein below. The parties agree that they neither will engage in any conduct or communications with a third party, public or private, designed to disparage the other. Neither Client nor any of Client’s associates, employees or affiliates will directly or indirectly, in any capacity or manner, make, express, transmit speak, write, verbalize or otherwise communicate in any way (or cause, further, assist, solicit, encourage, support or participate in any of the foregoing), any remark, comment, message, information, declaration, communication or other statement of any kind, whether verbal, in writing, electronically transferred or otherwise, that might reasonably be construed to be derogatory or critical of, or negative toward, the Company or any of its courses, members, owner directors, officers, Affiliates, subsidiaries, employees, agents or representatives.</p>

            <h4>ASSIGNMENT</h4>
            <p>Client may not assign this Agreement without express written consent of Company.</p>

            <h4>MODIFICATION</h4>
            <p>Company may modify terms of this agreement at any time. All modifications shall be posted on the Evolving Love website and purchasers shall be notified.</p>

            <h4>TERMINATION</h4>
            <p>Company is committed to providing all clients in the Course with a positive Course experience. By purchasing this product, Client agrees that the Company may, at its sole discretion, terminate this Agreement, and limit, suspend, or terminate Client’s participation in the Course without refund or forgiveness of monthly payments if Client becomes disruptive to Company or Participants, Client fails to follow the Program guidelines, is difficult to work with, impairs the participation of the other participants in the Course or upon violation of the terms as determined by Company. Client will still be liable to pay the total contract amount.</p>

            <h4>INDEMNIFICATION</h4>
            <p>Client shall defend, indemnify, and hold harmless Company, Company’s officers, employers, employees, contractors, directors, related entities, trustees, affiliates, representatives, and successors from and against any and all liabilities and expense whatsoever – including without limitation, claims, damages, judgments, awards, settlements, investigations, costs, attorneys fees, and disbursements – which any of them may incur or become obligated to pay arising out of or resulting from the offering for sale, the sale, and/or use of the product(s), excluding, however, any such expenses and liabilities which may result from a breach of this Agreement or sole negligence or willful misconduct by Company, or any of its shareholders, trustees, affiliates or successors. Client shall defend Company in any legal actions, regulatory actions, or the like arising from or related to this Agreement. Client recognizes and agrees that all of the Company’s shareholders, trustees, affiliates and successors shall not be held personally responsible or liable for any actions or representations of the Company. In consideration of and as part of my payment for the right to participate in the Course, the undersigned, my heirs, executors, administrators, successors and assigns do hereby release, waive, acquit, discharge, indemnify, defend, hold harmless and forever discharge the Bryan Franklin, Jennifer Russell, the Company and its subsidiaries, principals, directors, employees, agents, heirs, executors, administrators, successors, and assigns and any of the training instructors, guides, staff or students taking part in the training in any way as well as the venue where the Programs are being held (if applicable) and any of its owners, executives, agents, or staff (hereinafter "Releasees") of and from all actions, causes of action, contracts, claims, suits, costs, demands and damages of whatever nature or kind in law or in equity arising from my participation in the Courses.</p>

            <h4>RESOLUTION OF DISPUTES</h4>
            <p>If not resolved first by good-faith negotiation between the parties, every controversy or dispute relating to this Agreement will be submitted to the American Arbitration Association. All claims against Company must be lodged within 100-days of the date of the first claim or otherwise be forfeited forever. The arbitration shall occur within ninety (90) days from the date of the initial arbitration demand. The parties shall cooperate to ensure that the arbitration process is completed within the ninety (90) day period. The parties shall cooperate in exchanging and expediting discovery as part of the arbitration process. The written decision of the arbitrators (which will provide for the payment of costs) will be absolutely binding and conclusive and not subject to judicial review, and may be entered and enforced in any court of proper jurisdiction, either as a judgment of law or a decree in equity, as circumstances may indicate. In disputes involving unpaid balances on behalf of Client, Client is responsible for any and all arbitration and attorney fees.</p>

            <h4>NOTICES</h4>
            <p>Any notices to be given hereunder by either Party to the other may be effected by personal delivery or by mail, registered or certified, postage prepaid with return receipt requested. Notices delivered personally shall be deemed communicated as of the date of actual receipt; mailed notices shall be deemed communicated as of three (3) days after the date of mailing. For purposes of this Agreement, "personal delivery" includes notice transmitted by fax or email. Email: support[at]amyporterfield[dot]com. This Agreement shall be binding upon and inure to the benefit of the parties hereto, their respective heirs, executors, administrators, successors and permitted assigns. Any breach or the failure to enforce any provision hereof shall not constitute a waiver of that or any other provision in any other circumstance.This Agreement constitutes and contains the entire agreement between the parties with respect to its subject matter, supersedes all previous discussions, negotiations, proposals, agreements and understandings between them relating to such subject matter. This Agreement shall be governed by and construed in accordance with the laws of the State of California, United States of America.</p>

            <h4>ENTIRE AGREEMENT:</h4>
            <p>This Agreement represents the entire agreement and supersedes all prior agreements oral or written.</p>

            <h4>CONTACT US</h4>
            <p>If you do not understand or agree with any of these conditions, please do not order this material. If you require further clarification, please contact info@evolvinglove.us.</p>
            <p>If we can be of any assistance to you our contact details are:</p>
            <p>
                Evolving Love <br>
                23 Regulus Ct Alameda CA 94501 <br>
                Support: Jennifer Russell <br>
                Email: info@evolvinglove.us
            </p>
        </div>
    </section>
</main>
@include('layouts.footer')