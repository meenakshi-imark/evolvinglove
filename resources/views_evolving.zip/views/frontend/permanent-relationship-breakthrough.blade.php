@include('layouts.header')

<header id="header" class="site-header" style="background-image: url('{{asset('images/Evolving Love Sidebar & Practices Background - Red.png')}}');">
    <nav>
        <a href="javascript:void(0)" class="site-logo">
            <img src="{{asset('images/evolving-love-logo.png')}}" alt="">
        </a>
        <div class="right">
            <a href="#shopping_cart" class="btn btn-white upgrade-btn">REGISTER NOW</a>
        </div>
    </nav>
</header>
<main class="content">
    <section class="upgrade-banner uSpace permanent-section">
        <div class="container">
            <hgroup class="text-center">
                <h2>PERMANENT RELATIONSHIP BREAKTHROUGH <br> LIVE 8-WEEK VIRTUAL PROGRAM</h2>
                <h3 class="fw-normal">A PRACTICAL TOOLSET TO RESOLVE ANY CONFLICT & CREATE LASTING LOVE</h3>
                <figure>
                    <img src="{{asset('images/permanent-images/permanent_bnr.png')}}" alt="">
                </figure>
                <h3>Spend 8 Weeks of Guided Teaching, Practice & Discussions <br> Applying Proven Conflict Resolution Strategies</h3>
                <h3 class="fw-normal">Begins [Month Date Range Here] 2023</h3>
                <a href="#shopping_cart" class="btn btn-primary br">REGISTER NOW</a>
                <h4>Attend from anywhere - No hotels, flights, or sitters!</h4>
            </hgroup>
        </div>
    </section>

    <section class="uSpace background_primary">
        <div class="container">
            <div class="swiper testimonial-swiper">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="single">
                            <figure>
                                <img src="{{asset('images/upgrade/Evolving Love Testimonial - Kane & Alessia.png')}}" alt="">
                                <figcaption>Kane Minkus & Alessia Minkus</figcaption>
                            </figure>
                            <div class="text-content">
                                <p>“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.”</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="single">
                            <figure>
                                <img src="{{asset('images/upgrade/Evolving Love Testimonial - Annie & Eben.png')}}" alt="">
                                <figcaption>Annie Lalla & Eben Pagan</figcaption>
                            </figure>
                            <div class="text-content">
                                <p>“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.”</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="single">
                            <figure>
                                <img src="{{asset('images/upgrade/Evolving Love Testimonial - Kane & Alessia.png')}}" alt="">
                                <figcaption>Kane Minkus & Alessia Minkus</figcaption>
                            </figure>
                            <div class="text-content">
                                <p>“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.”</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="single">
                            <figure>
                                <img src="{{asset('images/upgrade/Evolving Love Testimonial - Annie & Eben.png')}}" alt="">
                                <figcaption>Annie Lalla & Eben Pagan</figcaption>
                            </figure>
                            <div class="text-content">
                                <p>“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.”</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="single">
                            <figure>
                                <img src="{{asset('images/upgrade/Evolving Love Testimonial - Kane & Alessia.png')}}" alt="">
                                <figcaption>Kane Minkus & Alessia Minkus</figcaption>
                            </figure>
                            <div class="text-content">
                                <p>“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.”</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="single">
                            <figure>
                                <img src="{{asset('images/upgrade/Evolving Love Testimonial - Annie & Eben.png')}}" alt="">
                                <figcaption>Annie Lalla & Eben Pagan</figcaption>
                            </figure>
                            <div class="text-content">
                                <p>“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.”</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </section>

    <section class="cover-image background_light_grey uSpace col_wrap">
        <figure class="bg-image"><img src="{{asset('images/Evolving Love Background - Android Jones Hope Street Night Machine.jpg')}}" alt=""></figure>
        <div class="container">
        <div class="maxWidth_1000 mx-auto">
            <div class="ctnt">
                <h2>WHAT YOU’LL GET</h2>
                <h4>PERSONALIZED INSIGHTS ABOUT YOURSELF & YOUR RELATIONSHIPS IN A LIVELY INTERACTIVE ENVIRONMENT WITH RELATIONSHIP EXPERTS JENNIFER RUSSELL & BRYAN FRANKLIN  </h4>
            </div>
            <div class="row row-cols-1 row-cols-md-3 gy-5">
                <div class="col">
                    <div class="single">
                        <figure><img src="{{asset('images/permanent-images/live-1.png')}}" alt="Evolving Love Icon - Personalized Plan (Puzzle Piece)"></figure>
                        <h3>Live Online 8 Week Course Including Recordings</h3>
                    </div>
                </div>
                <div class="col">
                    <div class="single">
                        <figure><img src="{{asset('images/permanent-images/live-2.png')}}" alt="Evolving Love Icon - Take It Together (Two Avatars)"></figure>
                        <h3>Downloadable Workbook With Practical Tools</h3>
                    </div>
                </div>
                <div class="col">
                    <div class="single">
                        <figure><img src="{{asset('images/permanent-images/live-3.png')}}" alt="Evolving Love Icon - Comprehensive Tool (Heart Cap and Gown)"></figure>
                        <h3>Interactive Discussions & Personalized Support</h3>
                    </div>
                </div>
                <div class="col">
                    <div class="single">
                        <figure><img src="{{asset('images/permanent-images/live-4.png')}}" alt="Evolving Love Icon - Take It Together (Two Avatars)"></figure>
                        <h3>BONUS#1: Personalized Relationship Archetype Profile</h3>
                    </div>
                </div>
                <div class="col">
                    <div class="single">
                        <figure><img src="{{asset('images/permanent-images/live-5.png')}}" alt="Evolving Love Icon - Comprehensive Tool (Heart Cap and Gown)"></figure>
                        <h3>BONUS#2: Mastering Your Relationship Archetype Course</h3>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </section>

    <section class="uSpace background_light_grey learn_section">
        <div class="container">
            <div class="maxWidth_1000 mx-auto">
            <hgroup class="text-center mb-4 mb-md-5">
                <h2>WHAT TO YOU’LL LEARN</h2>
                <h4 class="mb-0">MASTER THE CORE RELATIONSHIP PRINCIPLES THAT CREATE PERMANENT CHANGE</h4>
                <ul class="dots">
                    <li>Identify the 4 most common ‘toxic cycles’ at the heart of all conflict - exploring the patterns you get caught in  most </li>
                    <li>Learn the 5 R’s of Conflict Resolution, uncovering what you are already doing naturally and what you might bel eaving out</li>
                    <li>Discover specifically how you might be polarizing the people you relate to most in predictable ways and how to spot and unwind that behavior for both of you</li>
                    <li>Master the art of regulation, empathy, tracking, and de-escalating without giving up your truth</li>
                    <li>Diagnose what to do when you get triggered</li>
                    <li>express your needs and commit to a new future. </li>
                    <li>Learn how to reinterpret your blind spots and create a new narrative for your relationships. </li>
                    <li>Discover 8 remedies that will help you exit those common toxic cycles we get caught in so you can create more lasting love</li>
                    <li>Receive personalized and comprehensive insights about your Relationship Archetype Profile to more fully understand yourself and those you are relating to now</li>
                    <li>Discover why being good at “conflict resolution” - the way it’s normally taught - can actually hurt your relationships</li>
                    <li>Resolve once and for all your most painful recurring patterns and find out how to make sure your past conflicts don’t come back to haunt your next relationship</li>
                    <li>Learn the critical relationship skills that will set you up to be an even better partner, collaborator, family member, or friend.</li>
                </ul>
            </hgroup>
        </div>
        </div>
        <div class="relation_section" style="background-image:url('{{asset('images/permanent-images/btm_banner.png')}}')">
                <div class="container">
                    <div class="ctnt">
                    <p><strong>Welcome to the depths of the relational realm.</strong> This is where your deepest desires meet your most profound fears. It’s where you meet the edge of your limitations and <strong>learn to expand beyond them</strong>.</p>
                    <span>Learn to open, when you want to close.</span>
                    <p><strong>This course is not for the faint of heart</strong>. It’s for the courageous, the bold, and the daring. It’s for those who are willing to face their shadows and transmute them into light. It’s for those who are ready to step into their power and show up fully in their relationships.</p>
                    <p>strong>This course is more than just a series of teachings…</p>
                    <p>It’s an invitation to a deeper, more intimate connection with yourself and the people you are closest to.. </p>
                    <p>It’s an opportunity to explore the depths of your desires and fears.</p>
                    <p> It’s a chance to embody the qualities of Freedom, Devotion, Truth, Harmony, Passion, Partnership, Possibility, and Appreciation, . </p>
                    <p><strong> It’s a journey of self-discovery </strong>and self-realization.</p>
                    <span>Dare to love, no matter what.</span>
                    <p>So if you’re ready to dive deep into the depths of the relational realm, 
                    <strong>if you’re ready to face your shadows</strong> and transmute them into light, 
                    if you’re ready to step into your power and show up fully in your relationships, then join us on this journey of transformation.
                    </p>
                    <p>Let us guide you through the teachings of the 5 R’s of Conflict Resolution and help you master your archetypes. Let us help you awaken to the true nature of your being and experience the fullness of your feminine and masculine essence. Let us help you create extraordinary relationships that are grounded in love, trust, and authenticity.</p>
                    <h4>We are here for you. </h4>
                    </div>
                </div>
            </div>
    </section>

    <section class="permanent_area">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="area_img">
                        <img src="{{asset('images/permanent-images/permanent_bnr.png')}}">
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="ctnt text-center">
                        <h2>PERMANENT RELATIONSHIP BREAKTHROUGH:</h2>
                        <h3>8-Week Live Online Course [Date Here] 2023</h3>
                        <div class="text-center">
                            <a href="javascript:void(0)" class="btn btn-green br h-55">REGISTER NOW</a>
                        </div>
                        <p>Attend from anywhere - No hotels, flights, or sitters!</p>
                    </div>
                </div>
            </div>
        </div>                                                                                                                         
    </section>
    <section class="uSpace learn_section course_curriculum">
        <div class="container">
            <div class="maxWidth_1000 mx-auto">
            <hgroup class="text-center mb-4 mb-md-5">
                <h2>COURSE CURRICULUM</h2>
                <h4>A DEEP DIVE INTO THE 5 R’s OF  CONFLICT RESOLUTION & <br> THE 8 EVOLUTIONARY VIRTUES THAT CREATE LASTING LOVE</h4>
                <p>Over the course of eight weeks, we'll dive into the 5 R's of Resolution, exploring each one in depth and providing you with practical tools and exercises to apply in your relationships. You'll have access to video lessons, written materials, and lively interactive group discussions, so you can both learn at your own pace and get personalized support.</p>
            </hgroup>
            <div class="upgrade-list pt-3">
                <div class="row align-items-center gx-md-5">
                    <div class="col-md-4">
                        <figure>
                            <img src="{{asset('images/permanent-images/main-1.png')}}" alt="">
                        </figure>
                    </div>
                    <div class="col-md-8">
                        <h3>WEEK 1: THE 5 R’s OF CONFLICT RESOLUTION - Assess Your Gifts & Challenges</h3>
                        <ul class="dots">
                            <li>Discover the 5 essential steps to resolving conflicts permanently</li>
                            <li>Learn which of these steps you might be doing naturally and which are your growth edge</li>
                            <li>Practice how to turn conflict into an opportunity for healing and connection</li>
                        </ul>
                    </div>
                </div>
                <div class="row align-items-center gx-md-5">
                    <div class="col-md-4">
                        <figure>
                            <img src="{{asset('images/permanent-images/main-2.png')}}" alt="">
                        </figure>
                    </div>
                    <div class="col-md-8">
                        <h3>WEEK 2: THE RING OF RESOLUTION- The Roadmap to Permanent Change</h3>
                        <ul class="dots">
                            <li>Learn about the 8 toxic cycles that are at the center of all relationship conflicts</li>
                            <li>Discover the 8 relationship gifts that act as an exit ramp from our toxic cycles</li>
                            <li>Identify your unique relationship gifts and your primary and secondary shadow patterns</li>
                        </ul>
                    </div>
                </div>
                <div class="row align-items-center gx-md-5">
                    <div class="col-md-4">
                        <figure>
                            <img src="{{asset('images/permanent-images/main-3.png')}}" alt="">
                        </figure>
                    </div>
                    <div class="col-md-8">
                        <h3>WEEK 3: HOW TO REGULATE - Balance Your Nervous System & Return To Sanity</h3>
                        <ul class="dots">
                            <li>Discover practical techniques to regulate your emotions and return to a calm state</li>
                            <li>Cultivate presence and awareness to stay grounded even in challenging situations</li>
                            <li>Practice how to co-regulate with your partner, learning what each person needs most</li>
                        </ul>
                    </div>
                </div>
                <div class="row align-items-center gx-md-5">
                    <div class="col-md-4">
                        <figure>
                            <img src="{{asset('images/permanent-images/main-4.png')}}" alt="">
                        </figure>
                    </div>
                    <div class="col-md-8">
                        <h3>WEEK 4: HOW TO RESTORE - Empathy, Tracking & De-escalating</h3>
                        <ul class="dots">
                            <li>Develop empathy and understanding for your partner's perspective</li>
                            <li>Learn to hold space for your partner's emotions and needs</li>
                            <li>Practice tracking and de-escalating conflicts to prevent them from escalating further</li>
                        </ul>
                    </div>
                </div>
                <div class="row align-items-center gx-md-5">
                    <div class="col-md-4">
                        <figure>
                            <img src="{{asset('images/permanent-images/main-5.png')}}" alt="">
                        </figure>
                    </div>
                    <div class="col-md-8">
                        <h3>WEEK 5: HOW TO REINTERPRET - Illuminate Blindspots & Reveal A New Narrative</h3>
                        <ul class="dots">
                            <li>Identify limiting beliefs and stories that are impacting your relationship</li>
                            <li>Learn to reframe your thoughts and create a new narrative for your relationship</li>
                            <li>Practice dynamic listening and how to hold multiple perspectives to understand the situation more fully</li>
                        </ul>
                    </div>
                </div>
                <div class="row align-items-center gx-md-5">
                    <div class="col-md-4">
                        <figure>
                            <img src="{{asset('images/permanent-images/main-6.png')}}" alt="">
                        </figure>
                    </div>
                    <div class="col-md-8">
                        <h3>WEEK 6: HOW TO RESTRUCTURE - Express Your Needs, & Commit To A New Future</h3>
                        <ul class="dots">
                            <li>Practice communicating your needs effectively and clearly to your partner</li>
                            <li>Develop a shared vision and commitment to  your future together</li>
                            <li>Learn to make conscious choices that support your relationship goals</li>
                        </ul>
                    </div>
                </div>
                <div class="row align-items-center gx-md-5">
                    <div class="col-md-4">
                        <figure>
                            <img src="{{asset('images/permanent-images/main-7.png')}}" alt="">
                        </figure>
                    </div>
                    <div class="col-md-8">
                        <h3>WEEK 7: HOW TO RELEASE - Learn To Forgive & Release Lingering Resentment</h3>
                        <ul class="dots">
                            <li>Learn how to release any lingering resentment or pain</li>
                            <li>Cultivate longlasting compassion for yourself and your partner</li>
                            <li>Practice undefended requests for feedback to tend to the ongoing health of your relationship </li>
                        </ul>
                    </div>
                </div>
                <div class="row align-items-center gx-md-5">
                    <div class="col-md-4">
                        <figure>
                            <img src="{{asset('images/permanent-images/main-8.png')}}" alt="">
                        </figure>
                    </div>
                    <div class="col-md-8">
                        <h3>WEEK 8: PUTTING IT ALL TOGETHER - How To Permanently Resolve Your Conflicts</h3>
                        <ul class="dots">
                            <li>Practice the ‘Perfect Vision’ Conflict Resolution Process</li>
                            <li>Develop a plan to integrate the relational skills and strategies learned in the course.</li>
                            <li>Discover how to maintain a healthy and thriving relationship for the long-term. </li>
                        </ul>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </section>

    <section class="bg-cover meet_your background_primary uSpace" style="background-image: url('{{asset('images/Evolving Love Sidebar & Practices Background - Red.png')}}');">
        <div class="container">
            <hgroup class="text-center mb-5">
                <h2>MEET YOUR FACILITATORS BRYAN FRANKLIN & JENNIFER RUSSELL</h2>
                <h4>CO-FOUNDERS OF  EVOLVING LOVE | RELATIONSHIP EXPERTS | OVER 30,000 SESSIONS </h4>
            </hgroup>
            <div class="row mx-md-auto">
                <div class="col-md-4">
                    <figure>
                        <img src="{{asset('images/Hawaii-Bryan-and-Jennifer-BW.jpg')}}" alt="Hawaii-Bryan-and-Jennifer-BW" class="w-100">
                        <figcaption class="text-center mt-3"><strong>Jennifer Russell & Bryan Franklin</strong></figcaption>
                    </figure>
                </div>
                <div class="col-md-8">
                    <p>Together Jennifer and Bryan have led 20 years of impactful transformational programs and events designed to liberate people from self-imposed limiting beliefs and unlock their evolutionary potential. They incorporate the best of Neurolinguistic Programming (NLP), the human potential movement, family systems, attachment theory, collaborative systems, neuroscience, spiritual practices, tribal circling technologies, and sacred theater.</p>
                    <p>They are the co-founders of 'Evolving Love (https://evolvinglove.us), where they facilitate a series of retreats, workshops, and courses designed to rewrite your relational DNA so that you can  embody your ideal love story</p>
                    <p>They work with singles and couples to develop extraordinary relationships that point the way to significant personal evolution and the skills to develop a higher relational quotient (RQ).   They are a stand for relationships that have a 'both / and' rather than an 'either / or' relationship to Freedom and Devotion and realize the true potential that healing the divide between the masculine and feminine ihas on creating a healed, healthy, and whole culture.</p>
                    <p>They have developed powerful models that can help build the 3 pillars of any great relationship which are how to set the direction of your relationship, how to handle the valleys, and how to set the stage to experience the peaks.</p>
                </div>
            </div>
        </div>
    </section>

    <div class="relation_section" style="background-image:url('{{asset('images/permanent-images/middle_bnr.png')}}')">
        <div class="container">
            <div class="ctnt">
            <p>My Dearest Sisters,</p>
            <p><strong>I see you, I hear you, and I feel your pain. </strong>.</p>
            <p>I want you to know that  I honor your journey. </p>
            <p>I can sense your heart aching with a longing for healing, for a deeper <br> understanding and connection, for an end to the cycles of shaming and blaming <br> that have caused so much pain in our relationships. </p>
            <p>My sister, you are not alone in your longing.</p>

            <span>The greatest power, requires the lightest touch</span>
            <p><strong>When we disrespect men, we disrespect ourselves. </strong></p>
            <p>We become desensitized and disconnected from our own feminine power. </p>
            <p>We forget that our unique gifts and messages for the masculine are essential for <br> the balance of the world. </p>

            <p><strong>We forget that we are powerful beyond measure,</strong> and that we have the ability to transform the world with our love far better than with our fury.</p>
            <p>This course is an opportunity for us to heal the wounds that have kept us from fully expressing ourselves in our relationships to step into this space of love and transformation with us.</p>
            </div>
        </div>
    </div>
    <section class="uSpace learn_section course_curriculum background_light_grey product_list">
        <div class="container">
            <div class="maxWidth_1000 mx-auto">
            <hgroup class="text-center mb-4 mb-md-5">
                <h2>IS THIS COURSE RIGHT FOR YOU?</h2>
                <h4>WHO WILL BENEFIT MOST…AND WHO SHOULD LOOK ELSEWHERE….</h4>
            </hgroup>
            <div class="row">
                <div class="col-md-4">
                    <div class="product_img">
                        <img src="{{asset('images/permanent-images/product_1.jpg')}}">
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="ctnt">
                        <p><strong>As someone who is single right now, come to prepare yourself for a thriving relationship.  Learn the skills and proven strategies to better understand both yourself and others so you can build  a healthy relationship from the start.</strong></p>
                        <p>Come ready to unearth the blindspots and core patterns that are likely in the way from you finding true love and partnership.</p>
                        <p>Learn how to heal insecure attachment whether you are an avoidant type who tends to run away or need space OR whether you are an anxious type that tends to cling and hold too tightly to love.</p>
                        <p>Learn how to re-parent your wounded child so that you show up to your next relationship conscious, whole and complete.  Heal and unlearn these patterns before entering into your next relationship so that you can show up as the extraordinary lover you were naturally born to be.</p>
                        <p>Develop an evolutionary context for why you are in relationship to begin with that will inspire your future partner to want to take that journey alongside you.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="product_img">
                        <img src="{{asset('images/permanent-images/product_2.jpg')}}">
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="ctnt">
                        <p><strong>If you are in a relationship that ever faces challenges, come to this online event to identify and rise above the specific patterns that you get caught in most and learn personalized strategies that will support you to permanently resolve conflicts when they arise.</strong></p>
                        <p>Maybe you sometimes feel frustrated, insecure, unseen/unheard, smothered, under-nourished, or not completely loved the way that you want. Maybe you’ve even decided these feelings are a “normal” part of relationships.</p>
                        <p>Come ready to do the practices and have the conversations that will help you break free of some of these patterns.  You'll find the hidden symmetries that keep you thinking your relationship is out of balance.</p>
                        <p>Discover how you might be unintentionally leaking safety and trust out of your relationships. Learn to use conflict as an opportunity to connect and grow as you dismantle projections, embrace each other’s shadows, and heal old hurts.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="product_img">
                        <img src="{{asset('images/permanent-images/product_3.jpg')}}">
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="ctnt">
                        <p><strong>If you are a couple in bliss, you are already committed to having the best relationship possible. Come to create lasting change and healthy longevity that strengthens your relationship and evolves the way you love each other. </strong></p>
                        <p>We’ll guide you as you co-create an inspiring and evolutionary context for your relationship, up-leveling the way you relate and learning how to diffuse most conflict before it starts.</p>
                        <p>Enjoy lively discussions, experiential exercises and profound conversations that will spark growth and help you avoid misunderstandings.</p>
                        <p>Get a personalized plan that outlines how to best love your partner given your unique gifts and theirs.</p>
                        <p>Come dialogue with us about your deepest questions surrounding love and intimacy.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="product_img">
                        <img src="{{asset('images/permanent-images/product_4.jpg')}}">
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="ctnt">
                        <h3>IT WORKS ALONE OR TOGETHER</h3>
                        <p><strong>You don’t have to convince your partner to do this course with you</strong> in order to use the skills and conflict resolution process to heal old hurts in your relationship. Either partner can guide the conversation, and we’ll teach you how to make it easy for your partner to resolve conflicts with you, even if you think they are resistant to learning or following a “process”.  </p>
                        <p>Of course, it is also fabulous to do this course with your partner, creating juicy conversations and intimate moments together. </p>
                        <p>We’ve designed the exercises, practices, and live course interaction to work great if you are with your partner and work great if you are on your own. When it comes to resolving conflict, it actually only takes one to tango!</p>
                    </div>
                </div>
            </div>
            <div class="who_area">
                <h2>WHO This Course Is Not For</h2>
                <ul class="dots">
                    <li>Those who ate not interested in learning about their relationship patterns or improving their communication</li>
                    <li>People who are not willing to invest the time and effort necessary to create lasting change in their relationship.</li>
                    <li>Individuals who are looking for a magic solution to their relationship problem</li>
                    <li>Those who are not open-minded and willing to try new approaches to building stronger relationships</li>
                    <li>Couples who are in abusive or violent relationships</li>
                </ul>
                <p><strong>IMPORTANT:</strong> Please note that this course is not intended for couples who are in abusive or violent relationships. If you are experiencing abouse or violence in your relationship, please seek professional help immediately.</p>
            </div>
            </div>
        </div>
    </section>
    <section class="permanent_area">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="area_img">
                        <img src="{{asset('images/permanent-images/permanent_bnr.png')}}">
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="ctnt text-center">
                        <h2>PERMANENT RELATIONSHIP BREAKTHROUGH: </h2>
                        <h3>8-Week Live Online Course [Date Here] 2023</h3>
                        <div class="text-center">
                            <a href="javascript:void(0)" class="btn btn-green br h-55">REGISTER NOW</a>
                        </div>
                        <p>Attend from anywhere - No hotels, flights, or sitters!</p>
                    </div>
                </div>
            </div>
        </div>                                                                                                                         
    </section>
    <div class="relation_section" style="background-image:url('{{asset('images/permanent-images/bnr_bottom.png')}}')">
        <div class="container">
            <div class="ctnt">
            <p>Dearest Men.</p>
            <p><strong>We see you. We see the weight you carry,  </strong>the burdens you bear, and the struggles you face. </p>
            <p>We see the depth of your heart, the passion in your soul, and the potential within you. </p>
            <p>You are not broken. You are simply human, with all the messy complexities and contradictions that come with that.  </p>
            <p>And it is precisely those complexities that make you beautiful, that make you worthy of evolutionary love.</p>

            <span>Let us heal the divide between the masculine and feminine</span>
            <p>When we use our power with any force or push, it’s a sign we might actually be feeling powerless ourselves because the greatest power, requires the lightest touch and  it is in this gentle power that we learn how to wield it responsibly.</p>

            <p><strong>Let us heal the divide between men and women,</strong> and create a world where love and respect are the foundation of all our relationships.</p>
            </div>
        </div>
    </div>
    <section id="shopping_cart" class="uSpace">
        <div class="container">
            <div class="maxWidth_1000 mx-auto">
            <div class="row">
                <div class="col-md-9">
                    <form class="form payment-form">
                        <div class="text-center mb-4 pb-1">
                            <h2 class="mb-2">PAYMENT FORM</h2>
                            <p>Upgrade To Receive Your Full Report + 24 Lesson Guide</p>
                        </div>
                        <div class="control-group">
                            <div class="row align-items-center">
                                <div class="col-md-4">
                                    <label>First Name</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" placeholder="First Name" name="first_name">
                                </div>
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="row align-items-center">
                                <div class="col-md-4">
                                    <label>Last Name</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" placeholder="Last Name" name="last_name">
                                </div>
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="row align-items-center">
                                <div class="col-md-4">
                                    <label>Email</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="email" placeholder="Email" name="email">
                                </div>
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="row align-items-center">
                                <div class="col-md-4">
                                    <label>Cell Number (For Texting)</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" placeholder="Number" name="number">
                                </div>
                            </div>
                        </div>
                        <div class="control-group pt-2">
                            <div class="row align-items-center">
                                <div class="col-md-8 offset-md-4">
                                    <label>
                                        <input type="checkbox"> I agree to the <a href="terms-and-conditions.php">Terms and Conditions</a> of this course
                                    </label>
                                </div>
                            </div>
                        </div>

                        <hr>

                        <div class="control-group">
                            <div class="row align-items-center">
                                <div class="col-md-4">
                                    <label>Billing Address</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" placeholder="Billing Address" name="billing_address">
                                </div>
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="row align-items-center">
                                <div class="col-md-4">
                                    <label>Billing City</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" placeholder="Billing City" name="billing_city">
                                </div>
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="row align-items-center">
                                <div class="col-md-4">
                                    <label>Billing State</label>
                                </div>
                                <div class="col-md-8">
                                    <select name="billing_state">
                                        <option>Select...</option>
                                        <option>State 1</option>
                                        <option>State 2</option>
                                        <option>State 3</option>
                                        <option>State 4</option>
                                        <option>State 5</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="row align-items-center">
                                <div class="col-md-4">
                                    <label>Billing Country</label>
                                </div>
                                <div class="col-md-8">
                                    <select name="billing_country">
                                        <option>Select...</option>
                                        <option>Country 1</option>
                                        <option>Country 2</option>
                                        <option>Country 3</option>
                                        <option>Country 4</option>
                                        <option>Country 5</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="row align-items-center">
                                <div class="col-md-4">
                                    <label>Billing Zip</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" placeholder="Billing Zip" name="billing_zip">
                                </div>
                            </div>
                        </div>

                        <hr>

                        <h3>ENTER PAYMENT INFORMATION</h3>
                        <div class="control-group">
                            <div class="row align-items-center">
                                <div class="col-md-4"></div>
                                <div class="col-md-8">
                                    <div class="icon-container">
                                        <i class="fab fa-cc-visa" style="color:navy;"></i>
                                        <i class="fab fa-cc-amex" style="color:blue;"></i>
                                        <i class="fab fa-cc-mastercard" style="color:red;"></i>
                                        <i class="fab fa-cc-discover" style="color:orange;"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="row align-items-center">
                                <div class="col-md-4">
                                    <label>Card Number</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="number" placeholder="Card Number" name="card_number">
                                </div>
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="row align-items-center">
                                <div class="col-md-4">
                                    <label>Payment Code (CVC)</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="number" placeholder="CVC" name="cvc">
                                </div>
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="row align-items-center">
                                <div class="col-md-4">
                                    <label>Expiration Month</label>
                                </div>
                                <div class="col-md-8">
                                    <select name="expiration-month">
                                        <option>Select...</option>
                                        <option value="01">01 - January</option>
                                        <option value="02">02 - February</option>
                                        <option value="03">03 - March</option>
                                        <option value="04">04 - April</option>
                                        <option value="05">05 - May</option>
                                        <option value="06">06 - June</option>
                                        <option value="07">07 - July</option>
                                        <option value="08">08 - August</option>
                                        <option value="09">09 - September</option>
                                        <option value="10">10 - October</option>
                                        <option value="11">11 - November</option>
                                        <option value="12">12 - December</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="row align-items-center">
                                <div class="col-md-4">
                                    <label>Expiration Year</label>
                                </div>
                                <div class="col-md-8">
                                    <select name="expiration-year">
                                        <option>Select...</option>
                                        <option value="2022">2022</option>
                                        <option value="2023">2023</option>
                                        <option value="2024">2024</option>
                                        <option value="2025">2025</option>
                                        <option value="2026">2026</option>
                                        <option value="2027">2027</option>
                                        <option value="2028">2028</option>
                                        <option value="2029">2029</option>
                                        <option value="2030">2030</option>
                                        <option value="2031">2031</option>
                                        <option value="2032">2032</option>
                                        <option value="2033">2033</option>
                                        <option value="2034">2034</option>
                                        <option value="2035">2035</option>
                                        <option value="2036">2036</option>
                                        <option value="2037">2037</option>
                                        <option value="2038">2038</option>
                                        <option value="2039">2039</option>
                                        <option value="2040">2040</option>
                                        <option value="2041">2041</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <hr>

                        <h3>SHOPPING CART</h3>

                        <div class="table-responsive">
                            <table class="w-100">
                                <thead>
                                    <tr>
                                        <th>DESCRIPTION</th>
                                        <th>QTY</th>
                                        <th>PRICE</th>
                                        <th>TOTAL</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Full 40 Page Relationship Archetype Report
                                            + Step By Step Guide
                                        </td>
                                        <td>1</td>
                                        <td>$99.00</td>
                                        <td>$99.00</td>
                                    </tr>
                                    <tr>
                                        <td colspan="3" class="text-end">TOTAL</td>
                                        <td>$99.00</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="text-center mt-4 mt-md-5">
                            <a href="javascript:void(0)" class="btn btn-primary br">Purchase Now</a>
                        </div>
                    </form>
                </div>
                <div class="col-md-3">
                    <aside class="box-aside">
                        <div class="testi-single">
                            <p><em>“My partner and I got a series of tools to not only resolve our perpetual fights and conflicts, but also upgrade the very fabric of our relationship to become an exquisite crucible that allows us to transmute our problems into remarkable growth opportunities. I honestly cannot even imagine trying do "love" or "relationships" without these tools. Do yourself a service and do whatever it takes to learn this."</em></p>
                            <figure>
                                <img src="https://evolvinglove.customerdevsites.com/images/backend/testimonial-1on1/1680177088_Evolving Love Testimonial - Kevin Kurgansky (Circle) (1).png" alt="">
                                <figcaption>Kevin Kurgansky <span>The Breakup Doctor</span></figcaption>
                            </figure>
                        </div>
                                                <div class="testi-single">
                            <p><em>“I’ve spent multi-hour sessions with them and it was very unifying. They have this uncanny ability to really allow you to see your partner’s perspectives and have your partner see yours. I saw a whole new way of doing love—got a whole new set of distinctions, new ideas, and new ways of seeing things. These are a couple of the best in the world.”</em></p>
                            <figure>
                                <img src="https://evolvinglove.customerdevsites.com/images/backend/testimonial-1on1/1680177737_Evolving Love Testimonial - Eben Pagan (1).png" alt="">
                                <figcaption>Eben Pagan <span>Marketing &amp; Dating Expert</span></figcaption>
                            </figure>
                        </div>
                                                <div class="testi-single">
                            <p><em>"I feel like I've been waiting for this information all my life. My lens of what a relationship can be has widened and expanded. I now have a definition and knowing of what an extraordinary/ evolutionary relationship looks like/feels like and I know the way I do relationship and the way I work with my clients is forever changed."</em></p>
                            <figure>
                                <img src="https://evolvinglove.customerdevsites.com/images/backend/testimonial-1on1/1680177850_Evolving Love Testimonial - Maya Diamond (Circle).png" alt="">
                                <figcaption>Maya Diamond <span>MFT Therapist MA</span></figcaption>
                            </figure>
                        </div>
                                                
                        <div class="certified-box">
                            <figure>
                                <img src="https://evolvinglove.customerdevsites.com/images/secure-icon.png" alt="">
                            </figure>
                            <div>
                                <p><strong>128 BIT SSL</strong> SECURE SITE</p>
                                <p><small>100% Safe &amp; Secure Processing</small></p>
                            </div>
                        </div>
                    </aside>
                </div>
            </div>
            </div>
        </div>
    </section>

    <section class="uSpace background_light_grey">
        <div class="container">
            <hgroup class="text-center mb-5">
                <h2>FREQUENTLY ASKED QUESTIONS</h2>
                <h4>HERE ARE SOME HELPFUL ANSWERS TO SOME OF OUR MOST COMMON QUESTIONS</h4>
            </hgroup>
            <div class="accordion">
                <div class="accordion-item">
                    <a href="javascript:void(0)" class="title">Is this course right for me if I’m in a brand new relationship</a>
                    <div class="accordion-content" style="display: none;">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum commodo nisl ac pharetra aliquet.</p>
                    </div>
                </div>
                <div class="accordion-item">
                    <a href="javascript:void(0)" class="title">Is this a personality typing quiz?</a>
                    <div class="accordion-content" style="display: none;">
                        <p>The results you receive are not intended to be used as a ‘Typing’ system. Many typing systems describe our identity in a more fixed and one dimensional way. It may be tempting to think of the results in this report as meaning something about you that is unchangeable. Unlike most personality typing systems, your results in this Relationship Archetype Profile can be different if you re-take the Relationship Archetype quiz at different times and with different types or relationships in mind. It’s important to understand that no one is made of stone and this is not the kind of personality test that will tell you that you are and will always be a particular ‘type’. This Profile is meant to give you a window into how you are predominantly showing up in your relationships right now. It is a current snapshot of the most prevalent relational dynamics that are present in the relationship you had in mind and can be taken either with a romantic partner, business colleague, family member, or friend in mind.</p>
                    </div>
                </div>
                <div class="accordion-item">
                    <a href="javascript:void(0)" class="title">Is this course for couples only? Can I come if I’m not in a relationship now?</a>
                    <div class="accordion-content"  style="display: none;">
                        <p>You have the option of taking this course with or without your partner for an additional $1. If you include your partner’s details (name and email)  they will also get their own login and will be encouraged to take our Relationship Archetype Quiz.   You can take this course on your own to learn about yourself, the patterns and cycles you tend to get caught in and how to de-escalate and fully resolve conflicts.  It really only takes one of you willing to take one of the 8 key exit ramps we will be teaching you to begin the process of ending your conflicts.  So you are welcome to take this alone OR with your partner so you can both learn these critical relationship skills </p>
                    </div>
                </div>
                <div class="accordion-item">
                    <a href="javascript:void(0)" class="title">I’m single right now, will this Relationship Course still be valuable for me?
</a>
                    <div class="accordion-content" style="display: none;">
                        <p>Yes. It’s always incredibly valuable to understand yourself and others more deeply and filling out this quiz and receiving your profile when you are single is a great way for you to reflect on your past relationships and to look at the unique gifts you bring to others and the typical shadow patterns you might get caught in. This profile will help translate some of this knowledge into action as you uncover some of the remedies and relationship skills that you might want to develop. Although we recommend having a specific type of relationship in mind so that the profile accurately reflects how you tend to show up, you are welcome to reflect on your prior relationships and will gain a lot of insights that explain critically important dimensions of your particular relationship archetype.</p>
                    </div>
                </div>
                <div class="accordion-item">
                    <a href="javascript:void(0)" class="title">I am in really dire straits with my partner and am already seeing a therapist, do you think this course is appropriate for me? </a>
                    <div class="accordion-content" style="display: none;">
                        <p>After you initially take the Evolving Love Relationship Archetype Quiz, you will receive a free summary of your personalized results where 4 of the 24 sections of your profile will be unlocked. You will also have the option to purchase your full profile. When you select this option you’ll receive a login and password that will give you access to your personalized downloadable report + a 24 lesson online course that will walk you step by step through each section of your profile explaining critically important dimensions of your relationship archetype and the various gifts, tendencies, themes, needs, communication styles, and shadow patterns to help you understand yourself and others better. In addition the step by step guide includes relational skills and remedies and 21 practices to help translate knowledge into action so help you become an even better partner.</p>
                    </div>
                </div>
                <div class="accordion-item">
                    <a href="javascript:void(0)" class="title">I’m already in a great relationship is this course relevant for me?
</a>
                    <div class="accordion-content" style="display: none;">
                        <p>Your FULL profile + Step by Step Guide is uniquely tailored to you and contains 24 sections and a step by step course with videos, practices, and detailed explanations of the critical dimensions of your relationship that will walk you through your personalized results.</p>
                    </div>
                </div>
                <div class="accordion-item">
                    <a href="javascript:void(0)" class="title">How do I convince my partner to do this with me?</a>
                    <div class="accordion-content" style="display: none;">
                        <p>Yes you can take this quiz as many times as you like and can profile different relationships or even profile the same relationship at different times and get an in-depth analysis of your current relationship dynamics. It’s important to understand that no one is made of stone and even if we do tend to have some patterns and behaviors that are consistent in all our relationships, over time, as we develop, and as the people we are drawn to and are interacting with change, so do the relationship dynamics. The results you receive are not intended to be used as a ‘Typing’ system. Many typing systems describe our identity in a more fixed and one dimensional way. It may be tempting to think of the results in this report as meaning something about you that is unchangeable. The summary reports will always be free but you will need to purchase the upgrade to receive the full individualized profiles.</p>
                    </div>
                </div>
                <div class="accordion-item">
                    <a href="javascript:void(0)" class="title">Is there anything I should do to prepare for this course?
</a>
                    <div class="accordion-content" style="display: none;">
                        <p>The results you receive are not intended to be used as a ‘Typing’ system. Many typing systems describe our identity in a more fixed and one dimensional way. It may be tempting to think of the results in this report as meaning something about you that is unchangeable. Your results can be different if you re-take the Relationship Archetype quiz at different times and with different types or relationships in mind. It’s important to understand that no one is made of stone and this is not the kind of personality test that will tell you that you are and will always be a particular ‘type’. This Profile is meant to give you a window into how you are predominantly showing up in your relationships right now. It is a current snapshot of the most prevalent relational dynamics that are present in the relationship you had in mind and can be taken either with a romantic partner, business colleague, family member, or friend in mind.</p>
                    </div>
                </div>
                <div class="accordion-item">
                    <a href="javascript:void(0)" class="title">What will I learn in the Permanent Relationship Breakthrough Course?</a>
                    <div class="accordion-content" style="display: none;">
                        <p>Yes and highly encourage it. There is a ‘SHARE MY PROFILE’ button at the top of your Free Summary which will give you a special shareable link that you are welcome to send to others. In addition, if you purchased a full profile, you will receive an email in your inbox with a downloadable and shareable PDF you are welcome to send to your loved ones, business colleagues, family members, or friends. Please use the share button instead of copy pasting the URL, as this special link will allow them to see your results rather than showing a blank summary.</p>
                    </div>
                </div>

                <div class="accordion-item">
                    <a href="javascript:void(0)" class="title">I can’t afford it, what do I do? Are there any discounts available?</a>
                    <div class="accordion-content" style="display: none;">
                        <p>Yes and highly encourage it. There is a ‘SHARE MY PROFILE’ button at the top of your Free Summary which will give you a special shareable link that you are welcome to send to others. In addition, if you purchased a full profile, you will receive an email in your inbox with a downloadable and shareable PDF you are welcome to send to your loved ones, business colleagues, family members, or friends. Please use the share button instead of copy pasting the URL, as this special link will allow them to see your results rather than showing a blank summary.</p>
                    </div>
                </div>
                <div class="accordion-item">
                    <a href="javascript:void(0)" class="title">Is there a guarantee? What is your refund policy?</a>
                    <div class="accordion-content" style="display: none;">
                        <p>Yes and highly encourage it. There is a ‘SHARE MY PROFILE’ button at the top of your Free Summary which will give you a special shareable link that you are welcome to send to others. In addition, if you purchased a full profile, you will receive an email in your inbox with a downloadable and shareable PDF you are welcome to send to your loved ones, business colleagues, family members, or friends. Please use the share button instead of copy pasting the URL, as this special link will allow them to see your results rather than showing a blank summary.</p>
                    </div>
                </div>
                <div class="accordion-item">
                    <a href="javascript:void(0)" class="title">[Other questions here depending on whether format is ONLINE only or LIVE WORKSHOP]</a>
                    <div class="accordion-content" style="display: none;">
                        <p>Yes and highly encourage it. There is a ‘SHARE MY PROFILE’ button at the top of your Free Summary which will give you a special shareable link that you are welcome to send to others. In addition, if you purchased a full profile, you will receive an email in your inbox with a downloadable and shareable PDF you are welcome to send to your loved ones, business colleagues, family members, or friends. Please use the share button instead of copy pasting the URL, as this special link will allow them to see your results rather than showing a blank summary.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-cover background_primary text-center uSpace" style="background-image: url('{{asset('images/Evolving Love Sidebar & Practices Background - Red.png')}}');">
        <div class="container">
            <hgroup class="text-center mb-4 mb-md-5">
                <h2>STILL GOT QUESTIONS OR NEED SUPPORT?</h2>
                <h4 class="mb-0">If you’ve still got questions or need support click ‘GET SUPPORT’</h4>
                <h4 class="mb-0">Below and someone from our team will get back to you soon.</h4>
            </hgroup>
            <a href="javascript:void(0)" class="btn btn-white br">GET SUPPORT</a>
        </div>
    </section>
</main>



@include('layouts.footer')