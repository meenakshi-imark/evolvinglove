<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

    <!-- START HEADER/BANNER -->

    <tbody>
        <tr>
            <td align="center">
                <table class="col-600" width="600" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tbody>
                        <tr>
                            <td align="center" valign="top"
                                background="https://evolvinglove.customerdevsites.com/images/Evolving%20Love%20Background%20Image%20-%20Android%20Jones%20Union%20(hires).jpeg"
                                style="background-size:cover; background-position:bottom;height=" 400""="">
                                <table class="col-600" width="600" height="300" border="0" align="center"
                                    cellpadding="0" cellspacing="0">

                                    <tbody>
                                        <tr>
                                            <td height="40"></td>
                                        </tr>


                                        <tr>
                                            <td align="center" style="line-height: 0px;">
                                                <img style="display:block; line-height:0px; font-size:0px; border:0px;"
                                                    src="https://evolvinglove.customerdevsites.com/images/evolving-love-logo.png"
                                                    width="200" height="40" alt="logo">
                                            </td>
                                        </tr>


                                        <tr>
                                            <td height="40"></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>


        <!-- END HEADER/BANNER -->


        <!-- START 3 BOX SHOWCASE -->

        <tr>
            <td align="center">
                <table class="col-600" width="600" border="0" align="center" cellpadding="0" cellspacing="0"
                    style="margin-left:20px; margin-right:20px; border-left: 1px solid #dbd9d9; border-right: 1px solid #dbd9d9;">
                    <tbody>
                        <tr>
                            <td height="50"></td>
                        </tr>
                        <tr>
                            <td align="center"
                                style="font-family: 'Lato', sans-serif; font-size:20px; color:#757575; line-height:24px; font-weight: 300;">
                                Here is your  password
                            </td>
                        </tr>
                        <tr>
                            <td height="20"></td>
                        </tr>
                        <tr>
                            <td align="center"
                                style="font-family: 'Lato', sans-serif; font-size:18px; color:#000; line-height:24px; font-weight: 700;">
                                Password: {{$password}}
                            </td>
                        </tr>

                        <tr>
                            <td height="20"></td>
                        </tr>
                        <tr>
                            <td align="center"
                                style="font-family: 'Raleway', sans-serif; font-size:30px; font-weight: bold; color:#8A2F35;">
                                Thank You</td>
                        </tr>
                        <!-- <tr>
                            <td height="20"></td>
                        </tr> -->

                    </tbody>
                </table>
            </td>
        </tr>

        <!-- END 3 BOX SHOWCASE -->

        <!-- START WHAT WE DO -->

        <tr>
            <td align="center">
                <table class="col-600" width="600" border="0" align="center" cellpadding="0" cellspacing="0"
                    style="margin-left:20px; margin-right:20px;">



                    <tbody>

                        <!-- START FOOTER -->

                        <tr>
                            <td align="center">
                                <table align="center" width="100%" border="0" cellspacing="0" cellpadding="0"
                                    style=" border-left: 1px solid #dbd9d9; border-right: 1px solid #dbd9d9;">
                                    <tbody>
                                        <tr>
                                            <td height="50"></td>
                                        </tr>
                                        <tr>
                                            <td align="center" bgcolor="#8A2F35" height="185">
                                                <table align="center" width="35%" border="0" cellspacing="0"
                                                    cellpadding="0">
                                                    <tbody>
                                                        <tr>
                                                            <td align="center" width="30%" style="vertical-align: top;">
                                                                <a href="https://www.facebook.com/designmodo"
                                                                    target="_blank"> <img
                                                                        src="https://designmodo.com/demo/emailtemplate/images/icon-fb.png">
                                                                </a>
                                                            </td>

                                                            <td align="center" class="margin" width="30%"
                                                                style="vertical-align: top;">
                                                                <a href="https://twitter.com/designmodo"
                                                                    target="_blank"> <img
                                                                        src="https://designmodo.com/demo/emailtemplate/images/icon-twitter.png">
                                                                </a>
                                                            </td>

                                                            <td align="center" width="30%" style="vertical-align: top;">
                                                                <a href="https://plus.google.com/+Designmodo/posts"
                                                                    target="_blank"> <img
                                                                        src="https://designmodo.com/demo/emailtemplate/images/icon-googleplus.png">
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>



                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>

        <!-- END FOOTER -->



    </tbody>
</table>