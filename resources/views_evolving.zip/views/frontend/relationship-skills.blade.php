@include('layouts.header')

<main class="content">
    <section class="front-dashboard">
    @include('layouts.sidebar')
        <div class="main-area">
            <div class="page-title" style="background-image: url('{{ asset('images/banners/'.$relationship_lookup_text['banner'])}}');">
                <div class="sitemax-width">
                    <h1 class="mb-0">RELATIONSHIP ARCHETYPE</h1>
                    <h3 class="mb-0">{{$relationship_lookup_text['lookuptext']}}</h3>
                    <figure><img src="{{ asset('images/archetype_icon/'.$relationship_lookup_text['icon'])}}" alt=""></figure>
                </div>
            </div>
            <div class="page-content">
                <div class="sitemax-width">
                    <div class="page-breadcrum mb-6">
                        <a href="/themes" class="btn btn-secondary prev">
                            <i class="fas fa-caret-left"></i> Prev
                        </a>
                        <ul>
                            <li>Mastering Your Relationship Archetype</li>
                            <li>Relationship Archetype</li>
                            <li>Relationship Skills</li>
                        </ul>
                        <a href="/reference" class="btn btn-secondary next">
                            Next <i class="fas fa-caret-right"></i>
                        </a>
                    </div>

                    <div class="text-center mb-5">
                        <h2 class="color_black mb-0">RELATIONSHIP SKILLS</h2>
                    </div>
                    <h3>Relational Skills That Come Naturally</h3>
                    
                    <p>{{$natural_skills->relationship_skills_natural}}</p>

                    <h3>Relational Skills To Develop</h3>
                    <p>{{$develop_skills->relationship_skills_develop}}</p>

                    <div class="background-box my-6" style="background-image: url('images/Evolving Love Sidebar & Practices Background - Red.png');">
                        <img src="images/Evolving Love Icon - Thought Bubble.png" alt="">
                        <h3>EVOLVING LOVE PRACTICE</h3>
                        <p>Which of the three “Skills to develop” would have the most positive impact on your relationship? Choose the skill you most want to develop next.</p>
                        <ol class="small-spacing">
                            <li>Make a commitment to yourself to developing this new skill.</li>
                            <li>Share your commitment with your partner or someone you care about.</li>
                            <li>Share your answer along with how you think this skill will benefit you in the <a href="javascript:void(0)">Evolving Love Community</a></li>
                        </ol>
                    </div>

                    <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                    <ul class="small-spacing">
                        <li>Bullet one about why the next section is awesome</li>
                        <li>Bullet two about why the next section is awesome</li>
                        <li>Bullet three about why the next section is awesome</li>
                    </ul>
                    @include('layouts.feedback-box')

                    <div class="text-center my-6">
                    @php 
                    $datasession = session()->all();
                    $check_page = DB::table('progress_steps')->where('formid',$datasession['formid'])->where('page8','!=',NULL)->first();
                    @endphp
                    @if($check_page)
                    <button tyoe="submit" class="btn btn-primary br h-55" disabled style="border: 2px solid #008000;color: green;">Completed</button>
                    @else
                        <form method="post" action="/markcomplete">
                        @csrf
                        <input type="hidden" name="page" value="page8">
                        <button tyoe="submit" class="btn btn-primary br h-55">Mark Complete</button>
                        <form>
                    @endif
                    </div>

                    <div class="page-breadcrum mt-6">
                        <a href="/themes" class="btn btn-secondary prev">
                            <i class="fas fa-caret-left"></i> Prev
                        </a>
                        <ul>
                            <li>Mastering Your Relationship Archetype</li>
                            <li>Relationship Archetype</li>
                            <li>Relationship Skills</li>
                        </ul>
                        <a href="/reference" class="btn btn-secondary next">
                            Next <i class="fas fa-caret-right"></i>
                        </a>
                    </div>
                </div>
            </div>
            @include('layouts.promo-section')

        </div>
    </section>
</main>
@include('layouts.footer')