@include('layouts.header-quiz')


<main class="content">
    <section class="quiz-screen" style="background-image: url('{{ asset('images/Evolving Love Background Image - Android Jones Union (hires).jpeg')}}');">
        <div class="container">
            <div class="inner">
                <h2>Thank you for taking the time to fill out our Evolving Love RQ Assessment. Your report will be in your inbox soon.</h2>
                <p>Check out your results here: <a href="https://evolvinglove.customerdevsites.com/result-summary">https://evolvinglove.customerdevsites.com/result-summary</a></p>
                <ul class="mb-3">
                    <li>
                        <a href="javascript:void(0)"><i class="fab fa-facebook-square"></i></a>
                    </li>
                    <li>
                        <a href="javascript:void(0)"><i class="fab fa-twitter-square"></i></a>
                    </li>
                    <li>
                        <a href="javascript:void(0)"><i class="fab fa-linkedin"></i></a>
                    </li>
                </ul>
                <a href="/thank-you" class="btn btn-green mt-3">Reload</a>
            </div>
        </div>
    </section>
</main>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script>
$( document ).ready(function() {
    setTimeout(function() {
       window.location.href = "/pdf"
      }, 3000);
});
</script>
@include('layouts.footer')