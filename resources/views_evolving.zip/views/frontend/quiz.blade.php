@include('layouts.header-quiz')

<main class="content">
    <section class="quiz-screen" style="background-image: url('{{ asset('images/Evolving Love Background Image - Android Jones Union (hires).jpeg')}}');">
        <div class="container">
            <div class="inner">
                <figure class="mb-4"><img src="{{ asset('images/Evolving Love Polarity Wheel Updated (white lines).png')}}" alt=""></figure>
                <h1>EVOLVING LOVE <br> RELATIONSHIP ARCHETYPE QUIZ</h1>
                <p>Discover which skills will help you create an extraordinary relationship based on the 8 Evolving Love Archetypes</p>
                <a href="/statement" class="btn btn-white mt-3">START QUIZ</a>
            </div>
        </div>
    </section>
</main>
