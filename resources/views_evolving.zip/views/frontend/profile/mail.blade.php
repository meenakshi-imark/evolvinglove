<p>Hi <br>
You have a new submission
<br>

<br>
Name :{{$data['firstname']}} {{$data['lastname']}}<br>
Email :{{$data['email']}}<br>
Subject :{{$data['subject']}}<br>
Message :{{$data['message']}}<br>
<br>
Regards
<br>
Team Evolving Love
<p>

