@include('layouts.header-quiz')
<main class="content">
    <section class="quiz-screen" style="background-image: url('{{ asset('images/Evolving Love Background Image - Android Jones Union (hires).jpeg')}}');">
        <div class="container">
            <form method="post" id="question-submit">
                @csrf
                <div id="question1">
                    <!--div class="inner">
                        <h3 class="quiz-question">
                            <span><small>1)</small> What is your current relationship status?*</span>
                        </h3>
                        <div class="form type-checkbox w-100 mb-3">
                            <label>
                                <input type="radio" name="question1" value="I'm currently single and happy to stay that way for now">
                                <span>I'm currently single and happy to stay that way for now</span>
                            </label>
                            <label>
                                <input type="radio" name="question1" value="I'm currently single and wanting to find a relationship">
                                <span>I'm currently single and wanting to find a relationship</span>
                            </label>
                            <label>
                                <input type="radio" name="question1" value="I'm in a relationship that's really on the rocks">
                                <span>I'm in a relationship that's really on the rocks</span>
                            </label>
                            <label>
                                <input type="radio" name="question1" value="I'm in a relationship that's good but it's got some challenges">
                                <span>I'm in a relationship that's good but it's got some challenges</span>
                            </label>
                            <label>
                                <input type="radio" name="question1" value="I'm in a relationship that's in bliss">
                                <span>I'm in a relationship that's in bliss</span>
                            </label>
                            <label style="border: none;"><span class="text-danger" id="question1-error"></span></label>
                        </div>
                        <a href="javascript:void(0);" class="btn btn-white mt-3" id="next1" onClick="question1();">Next</a>
                    </div-->
                </div>
            </form>
        </div>
        <div class="bottom-links">

        </div>
    </section>
</main>
<style>
.quiz-screen .form.type-checkbox.yes-no label input[type=checkbox]:after, .quiz-screen .form.type-checkbox.yes-no label input[type=radio]:after {
    content: "N";
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script>
    
$("#question-submit").submit(function (e) {
    $.ajaxSetup({
    headers: {
      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
  });
    e.preventDefault();
    var formData = $("#question-submit").serialize();
    $.ajax({
      url: "/submit-form",
      type: "POST",
      dataType: "json",
      data: formData,
      success: function (data) {
        if (data.status == 1) {
            window.location = "/thankyou";          
        }

      },
    });
});

$( document ).ready(function() {
    $.ajax({
      url: "/get-questions",
      type: "GET",
      success:function(data){
			 $('#question1').html(data);
		}
    }); 
});

function nextquestion(id){
    $.ajax({
      url: "/get-next-questions",
      type: "GET",
      data: { id : id },
      success:function(data){
			 $('#question1').html(data);
		}
    }); 
}
</script>

<script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script src="{{asset('js/jquery-ui-touch-punch-min.js')}}"></script>
<script src="{{asset('js/bundle.min.js')}}"></script>
<script src="{{asset('js/quiz.js')}}"></script>

<!-- For Developer use -->
<script src="{{asset('js/developer.js')}}"></script>

<style>
    .text-danger {
        color: #fff !important;
    }
</style>
</body>

</html>